package com.example.game2048

import android.content.Context
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.game2048.databinding.ActivityMainBinding
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val engine = GameEngine()
    private lateinit var gestureDetector: GestureDetector
    private var prevBoard: Array<IntArray>? = null
    private var bestScore = 0
    private var shownWin = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load best score
        val prefs = getSharedPreferences("game2048", Context.MODE_PRIVATE)
        bestScore = prefs.getInt("best", 0)
        binding.tvBest.text = bestScore.toString()

        // Gesture detector for swipe
        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            private val SWIPE_THRESHOLD = 80
            private val VELOCITY_THRESHOLD = 100

            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent,
                velocityX: Float, velocityY: Float
            ): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y

                return if (abs(dx) > abs(dy)) {
                    if (abs(dx) > SWIPE_THRESHOLD && abs(velocityX) > VELOCITY_THRESHOLD) {
                        if (dx > 0) doMove(GameEngine.Direction.RIGHT)
                        else doMove(GameEngine.Direction.LEFT)
                        true
                    } else false
                } else {
                    if (abs(dy) > SWIPE_THRESHOLD && abs(velocityY) > VELOCITY_THRESHOLD) {
                        if (dy > 0) doMove(GameEngine.Direction.DOWN)
                        else doMove(GameEngine.Direction.UP)
                        true
                    } else false
                }
            }
        })

        binding.boardView.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            true
        }

        binding.btnNewGame.setOnClickListener { confirmNewGame() }

        updateUI()
    }

    private fun doMove(dir: GameEngine.Direction) {
        prevBoard = engine.getBoard()
        val moved = engine.move(dir)
        if (moved) {
            val state = engine.getState()
            binding.boardView.updateBoard(state.board, prevBoard)
            binding.tvScore.text = state.score.toString()

            if (state.score > bestScore) {
                bestScore = state.score
                binding.tvBest.text = bestScore.toString()
                getSharedPreferences("game2048", Context.MODE_PRIVATE)
                    .edit().putInt("best", bestScore).apply()
            }

            if (state.hasWon && !shownWin) {
                shownWin = true
                showWinDialog()
            } else if (state.isOver) {
                showGameOverDialog()
            }
        }
    }

    private fun updateUI() {
        val state = engine.getState()
        binding.boardView.updateBoard(state.board, null)
        binding.tvScore.text = state.score.toString()
        binding.tvBest.text = bestScore.toString()
    }

    private fun confirmNewGame() {
        AlertDialog.Builder(this)
            .setTitle("Yeni Oyun")
            .setMessage("Mevcut oyunu silmek istediğinizden emin misiniz?")
            .setPositiveButton("Evet") { _, _ -> startNewGame() }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun startNewGame() {
        shownWin = false
        prevBoard = null
        engine.reset()
        updateUI()
    }

    private fun showWinDialog() {
        AlertDialog.Builder(this)
            .setTitle("🎉 Kazandınız!")
            .setMessage("2048'e ulaştınız! Devam etmek ister misiniz?")
            .setPositiveButton("Devam Et", null)
            .setNegativeButton("Yeni Oyun") { _, _ -> startNewGame() }
            .show()
    }

    private fun showGameOverDialog() {
        AlertDialog.Builder(this)
            .setTitle("Oyun Bitti")
            .setMessage("Hamle kalmadı! Skor: ${engine.score}")
            .setPositiveButton("Tekrar Oyna") { _, _ -> startNewGame() }
            .setNegativeButton("Kapat", null)
            .show()
    }
}
