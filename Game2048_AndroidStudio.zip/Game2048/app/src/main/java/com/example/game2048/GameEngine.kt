package com.example.game2048

data class GameState(
    val board: Array<IntArray>,
    val score: Int,
    val isOver: Boolean,
    val hasWon: Boolean
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is GameState) return false
        return score == other.score &&
                isOver == other.isOver &&
                hasWon == other.hasWon &&
                board.contentDeepEquals(other.board)
    }
    override fun hashCode(): Int = board.contentDeepHashCode()
}

class GameEngine {

    companion object {
        const val SIZE = 4
        const val WIN_VALUE = 2048
    }

    private var board = Array(SIZE) { IntArray(SIZE) }
    var score = 0
        private set
    var hasWon = false
        private set
    var isOver = false
        private set

    init { reset() }

    fun reset() {
        board = Array(SIZE) { IntArray(SIZE) }
        score = 0
        hasWon = false
        isOver = false
        addRandomTile()
        addRandomTile()
    }

    fun getBoard(): Array<IntArray> = board.map { it.copyOf() }.toTypedArray()

    private fun addRandomTile() {
        val empty = mutableListOf<Pair<Int,Int>>()
        for (r in 0 until SIZE) for (c in 0 until SIZE)
            if (board[r][c] == 0) empty.add(r to c)
        if (empty.isEmpty()) return
        val (r, c) = empty.random()
        board[r][c] = if (Math.random() < 0.9) 2 else 4
    }

    enum class Direction { UP, DOWN, LEFT, RIGHT }

    fun move(dir: Direction): Boolean {
        if (isOver) return false
        val prev = board.map { it.copyOf() }.toTypedArray()

        when (dir) {
            Direction.LEFT  -> for (r in 0 until SIZE) board[r] = mergeRow(board[r])
            Direction.RIGHT -> for (r in 0 until SIZE) board[r] = mergeRow(board[r].reversedArray()).reversedArray()
            Direction.UP    -> for (c in 0 until SIZE) setCol(c, mergeRow(getCol(c)))
            Direction.DOWN  -> for (c in 0 until SIZE) setCol(c, mergeRow(getCol(c).reversedArray()).reversedArray())
        }

        val moved = !board.contentDeepEquals(prev)
        if (moved) {
            addRandomTile()
            if (!hasWon && board.any { row -> row.any { it >= WIN_VALUE } }) hasWon = true
            if (!canMove()) isOver = true
        }
        return moved
    }

    private fun mergeRow(row: IntArray): IntArray {
        val vals = row.filter { it != 0 }.toMutableList()
        var i = 0
        while (i < vals.size - 1) {
            if (vals[i] == vals[i + 1]) {
                vals[i] *= 2
                score += vals[i]
                vals.removeAt(i + 1)
            }
            i++
        }
        while (vals.size < SIZE) vals.add(0)
        return vals.toIntArray()
    }

    private fun getCol(c: Int) = IntArray(SIZE) { r -> board[r][c] }
    private fun setCol(c: Int, col: IntArray) { for (r in 0 until SIZE) board[r][c] = col[r] }

    private fun canMove(): Boolean {
        for (r in 0 until SIZE) for (c in 0 until SIZE) {
            if (board[r][c] == 0) return true
            if (c + 1 < SIZE && board[r][c] == board[r][c + 1]) return true
            if (r + 1 < SIZE && board[r][c] == board[r + 1][c]) return true
        }
        return false
    }

    fun getState() = GameState(getBoard(), score, isOver, hasWon)
}
