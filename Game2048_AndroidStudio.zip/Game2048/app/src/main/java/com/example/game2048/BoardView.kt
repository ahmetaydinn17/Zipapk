package com.example.game2048

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.ViewGroup

class BoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : ViewGroup(context, attrs, defStyle) {

    companion object {
        const val SIZE = 4
        const val GAP_DP = 10
    }

    private val tiles = Array(SIZE) { arrayOfNulls<TileView>(SIZE) }
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cellPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gap get() = (GAP_DP * resources.displayMetrics.density).toInt()

    init {
        setWillNotDraw(false)
        bgPaint.color  = 0xFF0D0D15.toInt()
        cellPaint.color = 0xFF161625.toInt()

        for (r in 0 until SIZE) {
            for (c in 0 until SIZE) {
                val tile = TileView(context)
                tiles[r][c] = tile
                addView(tile)
            }
        }
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        setMeasuredDimension(w, w) // square
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val size = r - l
        val totalGap = gap * (SIZE + 1)
        val tileSize = (size - totalGap) / SIZE

        for (row in 0 until SIZE) {
            for (col in 0 until SIZE) {
                val x = gap + col * (tileSize + gap)
                val y = gap + row * (tileSize + gap)
                tiles[row][col]?.layout(x, y, x + tileSize, y + tileSize)
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val g = gap.toFloat()
        val totalGap = g * (SIZE + 1)
        val tileSize = (w - totalGap) / SIZE
        val corner = 12f

        // Board background
        bgPaint.color = 0xFF0D0D15.toInt()
        canvas.drawRoundRect(RectF(0f, 0f, w, h), 16f, 16f, bgPaint)

        // Empty cells
        cellPaint.color = 0xFF161625.toInt()
        for (r in 0 until SIZE) {
            for (c in 0 until SIZE) {
                val x = g + c * (tileSize + g)
                val y = g + r * (tileSize + g)
                canvas.drawRoundRect(
                    RectF(x, y, x + tileSize, y + tileSize),
                    corner, corner, cellPaint
                )
            }
        }
    }

    fun updateBoard(board: Array<IntArray>, prevBoard: Array<IntArray>?) {
        for (r in 0 until SIZE) {
            for (c in 0 until SIZE) {
                val tile = tiles[r][c] ?: continue
                val newVal = board[r][c]
                val oldVal = prevBoard?.get(r)?.get(c) ?: -1
                if (newVal != oldVal) {
                    tile.value = newVal
                    when {
                        newVal == 0 -> { /* empty */ }
                        oldVal == 0 -> tile.animateAppear()
                        newVal > oldVal -> tile.animateMerge()
                    }
                }
            }
        }
    }
}
