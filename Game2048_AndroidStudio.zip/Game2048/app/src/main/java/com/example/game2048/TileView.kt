package com.example.game2048

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import android.view.animation.OvershootInterpolator

class TileView(context: Context) : View(context) {

    var value: Int = 0
        set(v) {
            field = v
            invalidate()
        }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val rect = RectF()
    private val cornerRadius = 12f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (value == 0) return

        val w = width.toFloat()
        val h = height.toFloat()
        rect.set(0f, 0f, w, h)

        // Background
        bgPaint.color = getTileBgColor(value)
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, bgPaint)

        // Shine overlay
        bgPaint.color = 0x0DFFFFFF
        val shineRect = RectF(0f, 0f, w, h * 0.45f)
        canvas.drawRoundRect(shineRect, cornerRadius, cornerRadius, bgPaint)

        // Text
        val text = value.toString()
        val fontSize = when {
            text.length <= 2 -> w * 0.42f
            text.length == 3 -> w * 0.34f
            text.length == 4 -> w * 0.26f
            else             -> w * 0.20f
        }
        textPaint.textSize = fontSize
        textPaint.color = getTileTextColor(value)
        val textY = h / 2f - (textPaint.descent() + textPaint.ascent()) / 2f
        canvas.drawText(text, w / 2f, textY, textPaint)
    }

    fun animateAppear() {
        scaleX = 0f; scaleY = 0f
        AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(this@TileView, "scaleX", 0f, 1f),
                ObjectAnimator.ofFloat(this@TileView, "scaleY", 0f, 1f)
            )
            duration = 150
            interpolator = OvershootInterpolator()
            start()
        }
    }

    fun animateMerge() {
        AnimatorSet().apply {
            playSequentially(
                AnimatorSet().apply {
                    playTogether(
                        ObjectAnimator.ofFloat(this@TileView, "scaleX", 1f, 1.2f),
                        ObjectAnimator.ofFloat(this@TileView, "scaleY", 1f, 1.2f)
                    )
                    duration = 100
                },
                AnimatorSet().apply {
                    playTogether(
                        ObjectAnimator.ofFloat(this@TileView, "scaleX", 1.2f, 1f),
                        ObjectAnimator.ofFloat(this@TileView, "scaleY", 1.2f, 1f)
                    )
                    duration = 100
                }
            )
            start()
        }
    }

    private fun getTileBgColor(v: Int): Int = when (v) {
        2    -> 0xFF2D2D4E.toInt()
        4    -> 0xFF36365A.toInt()
        8    -> 0xFF5C2D8A.toInt()
        16   -> 0xFF7A1F50.toInt()
        32   -> 0xFF7A2A18.toInt()
        64   -> 0xFF7A5510.toInt()
        128  -> 0xFF1A5C2A.toInt()
        256  -> 0xFF1A4A6E.toInt()
        512  -> 0xFF2A2A7A.toInt()
        1024 -> 0xFF5A1A7A.toInt()
        2048 -> 0xFF3A2A0A.toInt()
        else -> 0xFF1A0A3A.toInt()
    }

    private fun getTileTextColor(v: Int): Int = when (v) {
        2    -> 0xFFB0B0D0.toInt()
        4    -> 0xFFC0C0E0.toInt()
        8    -> 0xFFD580FF.toInt()
        16   -> 0xFFFF70B0.toInt()
        32   -> 0xFFFF8844.toInt()
        64   -> 0xFFFFCC33.toInt()
        128  -> 0xFF55EE88.toInt()
        256  -> 0xFF44CCFF.toInt()
        512  -> 0xFF8888FF.toInt()
        1024 -> 0xFFEE77FF.toInt()
        2048 -> 0xFFF7C948.toInt()
        else -> 0xFFFFFFFF.toInt()
    }
}
