# 2048 - Android Studio Projesi

Kotlin ile yazılmış, tam işlevsel 2048 oyunu.

## 🚀 Kurulum

1. Android Studio'yu açın (Hedgehog veya daha yeni)
2. `File > Open` → bu klasörü seçin
3. Gradle sync otomatik başlar
4. Emülatör veya fiziksel cihazda çalıştırın (`Run > Run 'app'`)

## 📋 Gereksinimler

- Android Studio Hedgehog (2023.1.1) veya üzeri
- Android SDK 34
- minSdk: Android 7.0 (API 24)
- Kotlin 1.9.0

## 🎮 Oyun Özellikleri

- **Kaydırma hareketi** ile oynama (yukarı/aşağı/sağ/sol)
- **Skor takibi** + kalıcı en iyi skor (SharedPreferences)
- **Animasyonlar**: taş belirim, birleşme
- **Kazanma/kaybetme** diyalogları
- **Türkçe arayüz**
- Koyu tema (#0A0A0F arka plan)

## 📁 Proje Yapısı

```
app/src/main/
├── java/com/example/game2048/
│   ├── GameEngine.kt      ← Oyun mantığı (taşıma, birleşme, skor)
│   ├── BoardView.kt       ← 4x4 ızgara ViewGroup
│   ├── TileView.kt        ← Tek kare custom View (renk + animasyon)
│   └── MainActivity.kt    ← Swipe gesture + UI güncelleme
└── res/
    ├── layout/activity_main.xml
    ├── values/themes.xml, colors.xml, strings.xml
    └── drawable/bg_score_box.xml
```
