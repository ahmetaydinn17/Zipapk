package com.example.blockgame

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import kotlin.math.min

class GameBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    interface BoardListener {
        fun onCellTapped(row: Int, col: Int)
    }

    var listener: BoardListener? = null
    var engine: GameEngine? = null
    var selectedPieceIdx: Int = -1

    private var cellSize: Float = 0f
    private var boardOffsetX: Float = 0f
    private var boardOffsetY: Float = 0f

    // Preview state
    var previewRow: Int = -1
    var previewCol: Int = -1
    var previewValid: Boolean = false

    // Clearing animation
    private val clearingRows = mutableSetOf<Int>()
    private val clearingCols = mutableSetOf<Int>()
    private var clearAnimProgress: Float = 1f
    private var clearAnimator: ValueAnimator? = null

    // Pop-in cells
    private val popInCells = mutableSetOf<Pair<Int, Int>>()
    private var popAnimProgress: Float = 1f
    private var popAnimator: ValueAnimator? = null

    private val cellPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0e0e1a")
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1a1a2e")
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1e1e2e")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    // Touch
    private var lastHoverR = -1
    private var lastHoverC = -1

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val eng = engine ?: return
        val padding = 4f
        val available = min(w, h) - padding * 2
        cellSize = available / eng.gridSize
        boardOffsetX = (w - cellSize * eng.gridSize) / 2f
        boardOffsetY = (h - cellSize * eng.gridSize) / 2f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val eng = engine ?: return

        val boardW = cellSize * eng.gridSize
        val boardH = cellSize * eng.gridSize

        // Board background
        canvas.drawRect(boardOffsetX, boardOffsetY, boardOffsetX + boardW, boardOffsetY + boardH, bgPaint)

        // Grid lines
        for (i in 0..eng.gridSize) {
            val x = boardOffsetX + i * cellSize
            val y = boardOffsetY + i * cellSize
            canvas.drawLine(x, boardOffsetY, x, boardOffsetY + boardH, gridPaint)
            canvas.drawLine(boardOffsetX, y, boardOffsetX + boardW, y, gridPaint)
        }

        // Filled cells
        for (r in 0 until eng.gridSize) {
            for (c in 0 until eng.gridSize) {
                val color = eng.grid[r][c] ?: continue
                val isClearingR = r in clearingRows
                val isClearingC = c in clearingCols
                val isClearing = isClearingR || isClearingC
                val isPopping = Pair(r, c) in popInCells

                val left = boardOffsetX + c * cellSize + 1f
                val top = boardOffsetY + r * cellSize + 1f
                val right = boardOffsetX + (c + 1) * cellSize - 1f
                val bottom = boardOffsetY + (r + 1) * cellSize - 1f

                val cx = (left + right) / 2f
                val cy = (top + bottom) / 2f
                val w2 = (right - left) / 2f
                val h2 = (bottom - top) / 2f

                var scaleX = 1f
                var scaleY = 1f
                var alpha = 255

                if (isClearing) {
                    scaleX = clearAnimProgress
                    scaleY = clearAnimProgress
                    alpha = (clearAnimProgress * 255).toInt()
                } else if (isPopping) {
                    val s = 0.5f + 0.5f * popAnimProgress
                    scaleX = s
                    scaleY = s
                }

                canvas.save()
                canvas.scale(scaleX, scaleY, cx, cy)

                // Glow
                glowPaint.color = color.glowInt
                glowPaint.alpha = (alpha * 0.6f).toInt()
                glowPaint.maskFilter = BlurMaskFilter(cellSize * 0.3f, BlurMaskFilter.Blur.NORMAL)
                canvas.drawRoundRect(left - 2, top - 2, right + 2, bottom + 2, 4f, 4f, glowPaint)

                // Cell fill
                cellPaint.color = color.colorInt
                cellPaint.alpha = alpha
                cellPaint.style = Paint.Style.FILL
                cellPaint.maskFilter = null
                canvas.drawRoundRect(left, top, right, bottom, 4f, 4f, cellPaint)

                // Inner highlight
                cellPaint.color = Color.WHITE
                cellPaint.alpha = (alpha * 0.15f).toInt()
                canvas.drawRoundRect(left + 2, top + 2, right - 2, top + (bottom - top) * 0.4f, 3f, 3f, cellPaint)

                canvas.restore()
            }
        }

        // Preview
        val piece = if (selectedPieceIdx >= 0) engine?.currentPieces?.getOrNull(selectedPieceIdx) else null
        if (piece != null && previewRow >= 0) {
            val halfR = piece.rows() / 2
            val halfC = piece.cols() / 2
            val startR = previewRow - halfR
            val startC = previewCol - halfC

            for (r in 0 until piece.rows()) {
                for (c in 0 until piece.cols()) {
                    if (piece.shape[r][c] == 0) continue
                    val gr = startR + r
                    val gc = startC + c
                    if (gr < 0 || gr >= eng.gridSize || gc < 0 || gc >= eng.gridSize) continue

                    val left = boardOffsetX + gc * cellSize + 1f
                    val top = boardOffsetY + gr * cellSize + 1f
                    val right = boardOffsetX + (gc + 1) * cellSize - 1f
                    val bottom = boardOffsetY + (gr + 1) * cellSize - 1f

                    cellPaint.maskFilter = null
                    if (previewValid) {
                        val color = GameColors.COLORS[piece.colorIndex]
                        cellPaint.color = color.colorInt
                        cellPaint.alpha = 120
                        cellPaint.style = Paint.Style.FILL
                        canvas.drawRoundRect(left, top, right, bottom, 4f, 4f, cellPaint)
                        cellPaint.color = color.colorInt
                        cellPaint.alpha = 200
                        cellPaint.style = Paint.Style.STROKE
                        cellPaint.strokeWidth = 2f
                        canvas.drawRoundRect(left, top, right, bottom, 4f, 4f, cellPaint)
                    } else {
                        cellPaint.color = Color.parseColor("#FF3366")
                        cellPaint.alpha = 80
                        cellPaint.style = Paint.Style.FILL
                        canvas.drawRoundRect(left, top, right, bottom, 4f, 4f, cellPaint)
                    }
                }
            }
        }

        // Board border
        canvas.drawRect(boardOffsetX, boardOffsetY, boardOffsetX + boardW, boardOffsetY + boardH, borderPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val eng = engine ?: return false
        val x = event.x - boardOffsetX
        val y = event.y - boardOffsetY
        val col = (x / cellSize).toInt()
        val row = (y / cellSize).toInt()

        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                if (row in 0 until eng.gridSize && col in 0 until eng.gridSize) {
                    if (row != lastHoverR || col != lastHoverC) {
                        lastHoverR = row
                        lastHoverC = col
                        updatePreview(row, col)
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                if (row in 0 until eng.gridSize && col in 0 until eng.gridSize) {
                    listener?.onCellTapped(row, col)
                }
                previewRow = -1
                previewCol = -1
                invalidate()
            }
        }
        return true
    }

    private fun updatePreview(row: Int, col: Int) {
        if (selectedPieceIdx < 0) return
        val piece = engine?.currentPieces?.getOrNull(selectedPieceIdx) ?: return
        val halfR = piece.rows() / 2
        val halfC = piece.cols() / 2
        previewRow = row
        previewCol = col
        previewValid = engine?.canPlace(piece, row - halfR, col - halfC) == true
        invalidate()
    }

    fun animateClear(rows: List<Int>, cols: List<Int>, onDone: () -> Unit) {
        clearingRows.clear()
        clearingCols.clear()
        clearingRows.addAll(rows)
        clearingCols.addAll(cols)
        clearAnimator?.cancel()
        clearAnimProgress = 1f
        clearAnimator = ValueAnimator.ofFloat(1f, 0f).apply {
            duration = 300
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                clearAnimProgress = it.animatedValue as Float
                invalidate()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    clearingRows.clear()
                    clearingCols.clear()
                    clearAnimProgress = 1f
                    onDone()
                    invalidate()
                }
            })
            start()
        }
    }

    fun animatePopIn(cells: List<Pair<Int, Int>>) {
        popInCells.clear()
        popInCells.addAll(cells)
        popAnimator?.cancel()
        popAnimProgress = 0f
        popAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 200
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                popAnimProgress = it.animatedValue as Float
                invalidate()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    popInCells.clear()
                    popAnimProgress = 1f
                    invalidate()
                }
            })
            start()
        }
    }
}
