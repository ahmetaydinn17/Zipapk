package com.example.blockgame

import android.graphics.Color

// Represents a single cell's color info
data class CellColor(val colorInt: Int, val glowInt: Int)

// Represents a placeable piece
data class GamePiece(
    val shape: Array<IntArray>,
    val colorIndex: Int
) {
    fun rows() = shape.size
    fun cols() = shape[0].size

    fun cellCount(): Int = shape.sumOf { row -> row.sum() }

    fun rotated(): GamePiece {
        val rows = shape.size
        val cols = shape[0].size
        val newShape = Array(cols) { IntArray(rows) }
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                newShape[c][rows - 1 - r] = shape[r][c]
            }
        }
        return GamePiece(newShape, colorIndex)
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is GamePiece) return false
        return colorIndex == other.colorIndex && shape.contentDeepEquals(other.shape)
    }

    override fun hashCode(): Int = 31 * colorIndex + shape.contentDeepHashCode()
}

object GameColors {
    val COLORS = listOf(
        CellColor(Color.parseColor("#00FFCC"), Color.parseColor("#004433")),
        CellColor(Color.parseColor("#FF3366"), Color.parseColor("#440011")),
        CellColor(Color.parseColor("#FFCC00"), Color.parseColor("#443300")),
        CellColor(Color.parseColor("#3399FF"), Color.parseColor("#002244")),
        CellColor(Color.parseColor("#FF6600"), Color.parseColor("#441800")),
        CellColor(Color.parseColor("#CC44FF"), Color.parseColor("#330044")),
        CellColor(Color.parseColor("#00FF66"), Color.parseColor("#004422")),
    )
}

object PieceFactory {
    private val SHAPES = listOf(
        arrayOf(intArrayOf(1)),                                         // 1x1
        arrayOf(intArrayOf(1, 1)),                                      // 1x2
        arrayOf(intArrayOf(1), intArrayOf(1)),                          // 2x1
        arrayOf(intArrayOf(1, 1, 1)),                                   // 1x3
        arrayOf(intArrayOf(1), intArrayOf(1), intArrayOf(1)),           // 3x1
        arrayOf(intArrayOf(1, 1, 1, 1)),                                // 1x4
        arrayOf(intArrayOf(1, 1), intArrayOf(1, 1)),                    // 2x2
        arrayOf(intArrayOf(1, 1, 1), intArrayOf(1, 0, 0)),              // L
        arrayOf(intArrayOf(1, 1, 1), intArrayOf(0, 0, 1)),              // J
        arrayOf(intArrayOf(1, 0), intArrayOf(1, 0), intArrayOf(1, 1)), // L2
        arrayOf(intArrayOf(0, 1), intArrayOf(0, 1), intArrayOf(1, 1)), // J2
        arrayOf(intArrayOf(1, 1, 0), intArrayOf(0, 1, 1)),              // S
        arrayOf(intArrayOf(0, 1, 1), intArrayOf(1, 1, 0)),              // Z
        arrayOf(intArrayOf(0, 1, 0), intArrayOf(1, 1, 1)),              // T
        arrayOf(intArrayOf(1, 1, 1), intArrayOf(0, 1, 0)),              // T2
        arrayOf(intArrayOf(1, 0), intArrayOf(1, 1), intArrayOf(1, 0)), // T3
        arrayOf(intArrayOf(1, 1, 1), intArrayOf(1, 0, 0), intArrayOf(1, 0, 0)), // BigL
        arrayOf(intArrayOf(1, 1, 1, 1, 1)),                             // 1x5
        arrayOf(intArrayOf(1, 1), intArrayOf(1, 0), intArrayOf(1, 0)), // SmL
        arrayOf(intArrayOf(3 - 3 + 1, 0), intArrayOf(1, 1), intArrayOf(0, 1)), // S2
    )

    fun random(): GamePiece {
        val shape = SHAPES[(Math.random() * SHAPES.size).toInt()]
        val colorIdx = (Math.random() * GameColors.COLORS.size).toInt()
        var piece = GamePiece(shape.map { it.clone() }.toTypedArray(), colorIdx)
        val rotations = (Math.random() * 4).toInt()
        repeat(rotations) { piece = piece.rotated() }
        return piece
    }
}
