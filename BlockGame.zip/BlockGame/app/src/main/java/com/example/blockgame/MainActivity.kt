package com.example.blockgame

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.blockgame.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), GameBoardView.BoardListener {

    private lateinit var binding: ActivityMainBinding
    private val engine = GameEngine()
    private var selectedPieceIdx = -1
    private val handler = Handler(Looper.getMainLooper())

    private val prefs by lazy { getSharedPreferences("blockgame", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Fullscreen
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_FULLSCREEN
        )

        binding.boardView.listener = this
        binding.boardView.engine = engine

        setupPieceSlots()
        setupButtons()

        val best = prefs.getInt("best_score", 0)
        startNewGame(best)
    }

    private fun setupPieceSlots() {
        val slots = listOf(binding.piece0, binding.piece1, binding.piece2)
        slots.forEachIndexed { idx, view ->
            view.setOnClickListener {
                if (!view.isUsed) selectPiece(idx)
            }
        }
    }

    private fun setupButtons() {
        binding.btnNewGame.setOnClickListener {
            if (binding.overlayGameOver.visibility == View.VISIBLE) {
                hideGameOver()
            }
            startNewGame(engine.bestScore)
        }
        binding.btnOverlayRestart.setOnClickListener {
            hideGameOver()
            startNewGame(engine.bestScore)
        }
        binding.btnRotate.setOnClickListener {
            if (selectedPieceIdx >= 0) {
                engine.rotatePiece(selectedPieceIdx)
                updatePieceViews()
                binding.boardView.previewRow = -1
                binding.boardView.previewCol = -1
                binding.boardView.invalidate()
            }
        }
    }

    private fun startNewGame(savedBest: Int) {
        selectedPieceIdx = -1
        binding.boardView.selectedPieceIdx = -1
        binding.boardView.previewRow = -1
        binding.boardView.previewCol = -1
        engine.newGame(savedBest)
        updateUI()
        updatePieceViews()
        binding.boardView.invalidate()
        binding.comboText.visibility = View.INVISIBLE
    }

    private fun selectPiece(idx: Int) {
        selectedPieceIdx = if (selectedPieceIdx == idx) -1 else idx
        binding.boardView.selectedPieceIdx = selectedPieceIdx
        binding.boardView.previewRow = -1
        binding.boardView.previewCol = -1
        binding.boardView.invalidate()
        updatePieceViews()
    }

    override fun onCellTapped(row: Int, col: Int) {
        if (selectedPieceIdx < 0) return
        val piece = engine.currentPieces.getOrNull(selectedPieceIdx) ?: return

        val halfR = piece.rows() / 2
        val halfC = piece.cols() / 2
        val startR = row - halfR
        val startC = col - halfC

        val result = engine.placePiece(selectedPieceIdx, startR, startC) ?: return

        // Collect placed cells for animation
        val placedCells = mutableListOf<Pair<Int, Int>>()
        for (r in 0 until piece.rows()) {
            for (c in 0 until piece.cols()) {
                if (piece.shape[r][c] != 0) {
                    placedCells.add(Pair(startR + r, startC + c))
                }
            }
        }

        selectedPieceIdx = -1
        binding.boardView.selectedPieceIdx = -1
        binding.boardView.previewRow = -1
        binding.boardView.previewCol = -1

        updatePieceViews()
        updateUI()

        // Save best
        prefs.edit().putInt("best_score", engine.bestScore).apply()

        // Show score popup
        showScorePopup(result.score, row, col)

        // Combo display
        if (engine.comboCount >= 2) showCombo(engine.comboCount)
        else binding.comboText.visibility = View.INVISIBLE

        if (result.linesCleared > 0) {
            binding.boardView.animateClear(result.clearedRows, result.clearedCols) {
                binding.boardView.invalidate()
                if (engine.gameOver) showGameOver()
            }
        } else {
            binding.boardView.animatePopIn(placedCells)
            if (engine.gameOver) {
                handler.postDelayed({ showGameOver() }, 400)
            }
        }
    }

    private fun updateUI() {
        animateNumber(binding.scoreText, engine.score)
        animateNumber(binding.bestText, engine.bestScore)
        binding.levelText.text = engine.level.toString()
        binding.clearedText.text = engine.totalCleared.toString()
        binding.placedText.text = engine.totalPlaced.toString()
        binding.comboStatText.text = "${engine.comboCount}x"

        // Level bar
        val progress = engine.levelProgress()
        binding.levelBarFill.post {
            val params = binding.levelBarFill.layoutParams
            params.width = (binding.levelBarBg.width * progress).toInt()
            binding.levelBarFill.layoutParams = params
        }
    }

    private fun animateNumber(tv: TextView, target: Int) {
        val current = tv.text.toString().toIntOrNull() ?: 0
        if (current == target) return
        val anim = ValueAnimator.ofInt(current, target).apply {
            duration = 300
            addUpdateListener { tv.text = (it.animatedValue as Int).toString() }
        }
        anim.start()
        // Flash
        tv.animate().scaleX(1.2f).scaleY(1.2f).setDuration(150).withEndAction {
            tv.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
        }.start()
    }

    private fun updatePieceViews() {
        val views = listOf(binding.piece0, binding.piece1, binding.piece2)
        views.forEachIndexed { idx, view ->
            val piece = engine.currentPieces.getOrNull(idx)
            view.piece = piece
            view.isUsed = piece == null
            view.isSelected = idx == selectedPieceIdx
        }
    }

    private fun showScorePopup(pts: Int, row: Int, col: Int) {
        val popup = binding.scorePopup
        popup.text = "+$pts"
        popup.visibility = View.VISIBLE
        popup.alpha = 1f
        popup.translationY = 0f

        // Rough position above tapped cell
        popup.animate()
            .alpha(0f)
            .translationY(-80f)
            .setDuration(800)
            .withEndAction { popup.visibility = View.INVISIBLE }
            .start()
    }

    private fun showCombo(count: Int) {
        binding.comboText.text = "${count}X COMBO!"
        binding.comboText.visibility = View.VISIBLE
        binding.comboText.alpha = 0f
        binding.comboText.scaleX = 0.5f
        binding.comboText.scaleY = 0.5f
        binding.comboText.animate()
            .alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(200)
            .setInterpolator(OvershootInterpolator())
            .start()
    }

    private fun showGameOver() {
        binding.overlayScore.text = engine.score.toString()
        binding.overlayBestLabel.text = if (engine.score >= engine.bestScore)
            "🏆 YENİ REKOR!" else "En yüksek: ${engine.bestScore}"

        binding.overlayGameOver.visibility = View.VISIBLE
        binding.overlayGameOver.alpha = 0f
        binding.overlayGameOver.animate().alpha(1f).setDuration(400).start()
    }

    private fun hideGameOver() {
        binding.overlayGameOver.animate()
            .alpha(0f)
            .setDuration(200)
            .withEndAction { binding.overlayGameOver.visibility = View.GONE }
            .start()
    }
}
