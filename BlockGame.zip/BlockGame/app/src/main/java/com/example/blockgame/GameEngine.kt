package com.example.blockgame

data class PlacementResult(
    val linesCleared: Int,
    val cellsPlaced: Int,
    val score: Int,
    val clearedRows: List<Int>,
    val clearedCols: List<Int>
)

class GameEngine(val gridSize: Int = 10) {

    val grid: Array<Array<CellColor?>> = Array(gridSize) { arrayOfNulls(gridSize) }
    var score: Int = 0
        private set
    var bestScore: Int = 0
    var level: Int = 1
        private set
    var totalCleared: Int = 0
        private set
    var totalPlaced: Int = 0
        private set
    var comboCount: Int = 0
        private set

    var currentPieces: Array<GamePiece?> = arrayOfNulls(3)
    var gameOver: Boolean = false

    fun newGame(savedBest: Int) {
        for (r in 0 until gridSize) for (c in 0 until gridSize) grid[r][c] = null
        score = 0
        bestScore = savedBest
        level = 1
        totalCleared = 0
        totalPlaced = 0
        comboCount = 0
        gameOver = false
        generatePieces()
    }

    fun generatePieces() {
        currentPieces = Array(3) { PieceFactory.random() }
    }

    fun canPlace(piece: GamePiece, startR: Int, startC: Int): Boolean {
        for (r in 0 until piece.rows()) {
            for (c in 0 until piece.cols()) {
                if (piece.shape[r][c] == 0) continue
                val gr = startR + r
                val gc = startC + c
                if (gr < 0 || gr >= gridSize || gc < 0 || gc >= gridSize) return false
                if (grid[gr][gc] != null) return false
            }
        }
        return true
    }

    fun placePiece(pieceIdx: Int, startR: Int, startC: Int): PlacementResult? {
        val piece = currentPieces[pieceIdx] ?: return null
        if (!canPlace(piece, startR, startC)) return null

        val color = GameColors.COLORS[piece.colorIndex]
        var cellsPlaced = 0
        for (r in 0 until piece.rows()) {
            for (c in 0 until piece.cols()) {
                if (piece.shape[r][c] == 0) continue
                grid[startR + r][startC + c] = color
                cellsPlaced++
            }
        }

        currentPieces[pieceIdx] = null
        totalPlaced++

        // Find lines to clear
        val rowsToClear = mutableListOf<Int>()
        val colsToClear = mutableListOf<Int>()

        for (r in 0 until gridSize) {
            if (grid[r].all { it != null }) rowsToClear.add(r)
        }
        for (c in 0 until gridSize) {
            if (grid.all { row -> row[c] != null }) colsToClear.add(c)
        }

        val linesCleared = rowsToClear.size + colsToClear.size

        if (linesCleared > 0) {
            comboCount++
            totalCleared += linesCleared
            // Clear
            rowsToClear.forEach { r -> for (c in 0 until gridSize) grid[r][c] = null }
            colsToClear.forEach { c -> for (r in 0 until gridSize) grid[r][c] = null }
        } else {
            comboCount = 0
        }

        // Calculate score
        val baseScore = cellsPlaced * 10
        var lineBonus = 0
        for (i in 1..linesCleared) lineBonus += i * 100 * level
        val comboBonus = if (comboCount > 1) comboCount * 50 * level else 0
        val pts = baseScore + lineBonus + comboBonus

        score += pts
        if (score > bestScore) bestScore = score

        // Update level
        level = totalCleared / 5 + 1

        // Regenerate if all used
        if (currentPieces.all { it == null }) generatePieces()

        // Check game over
        gameOver = !hasAnyValidMove()

        return PlacementResult(linesCleared, cellsPlaced, pts, rowsToClear, colsToClear)
    }

    fun rotatePiece(idx: Int) {
        currentPieces[idx] = currentPieces[idx]?.rotated()
    }

    fun hasAnyValidMove(): Boolean {
        for (piece in currentPieces) {
            if (piece == null) continue
            for (r in 0..gridSize - piece.rows()) {
                for (c in 0..gridSize - piece.cols()) {
                    if (canPlace(piece, r, c)) return true
                }
            }
        }
        return false
    }

    fun levelProgress(): Float {
        val xpNeeded = level * 5
        return (totalCleared % xpNeeded).toFloat() / xpNeeded
    }
}
