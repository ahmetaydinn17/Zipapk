package com.example.blockgame

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

class PieceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var piece: GamePiece? = null
        set(value) {
            field = value
            invalidate()
        }

    var isSelected: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var isUsed: Boolean = false
        set(value) {
            field = value
            alpha = if (value) 0.2f else 1f
            isClickable = !value
            invalidate()
        }

    private val cellPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#12121a")
        style = Paint.Style.FILL
    }
    private val selectedBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00FFCC")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val dimBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1e1e2e")
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val p = piece ?: return

        val w = width.toFloat()
        val h = height.toFloat()
        val padding = 8f

        // Background
        canvas.drawRoundRect(0f, 0f, w, h, 4f, 4f, bgPaint)
        canvas.drawRoundRect(0f, 0f, w, h, 4f, 4f, if (isSelected) selectedBorderPaint else dimBorderPaint)

        if (isSelected) {
            // Glow bg
            glowPaint.color = Color.parseColor("#00FFCC")
            glowPaint.alpha = 20
            glowPaint.maskFilter = BlurMaskFilter(20f, BlurMaskFilter.Blur.NORMAL)
            glowPaint.style = Paint.Style.FILL
            canvas.drawRoundRect(0f, 0f, w, h, 4f, 4f, glowPaint)
        }

        // Calculate cell size to fit piece
        val rows = p.rows()
        val cols = p.cols()
        val cellW = (w - padding * 2) / cols
        val cellH = (h - padding * 2) / rows
        val cellSize = min(cellW, cellH).coerceAtMost(20f)

        val totalW = cellSize * cols
        val totalH = cellSize * rows
        val startX = (w - totalW) / 2f
        val startY = (h - totalH) / 2f

        val color = GameColors.COLORS[p.colorIndex]
        val gap = 1f

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (p.shape[r][c] == 0) continue
                val left = startX + c * cellSize + gap
                val top = startY + r * cellSize + gap
                val right = startX + (c + 1) * cellSize - gap
                val bottom = startY + (r + 1) * cellSize - gap

                glowPaint.color = color.colorInt
                glowPaint.alpha = 60
                glowPaint.maskFilter = BlurMaskFilter(cellSize * 0.4f, BlurMaskFilter.Blur.NORMAL)
                glowPaint.style = Paint.Style.FILL
                canvas.drawRoundRect(left - 1, top - 1, right + 1, bottom + 1, 3f, 3f, glowPaint)

                cellPaint.color = color.colorInt
                cellPaint.alpha = 255
                cellPaint.maskFilter = null
                cellPaint.style = Paint.Style.FILL
                canvas.drawRoundRect(left, top, right, bottom, 3f, 3f, cellPaint)

                // Highlight
                cellPaint.color = Color.WHITE
                cellPaint.alpha = 40
                canvas.drawRoundRect(left + 1, top + 1, right - 1, top + (bottom - top) * 0.35f, 2f, 2f, cellPaint)
            }
        }
    }
}
