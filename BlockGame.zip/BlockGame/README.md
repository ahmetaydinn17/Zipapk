# BLOK — Block Placement Game
## Android Studio Kurulum Talimatları

### Gereksinimler
- Android Studio Hedgehog (2023.1.1) veya üzeri
- Android SDK 34
- Kotlin 1.9+
- Min Android API 24 (Android 7.0)

### Açılış
1. Android Studio'yu aç
2. **File → Open** seçin
3. Bu klasörü (`BlockGame/`) seçin
4. Gradle sync otomatik başlayacak — tamamlanmasını bekleyin
5. Emülatör veya fiziksel cihazda **Run** edin

### Oyun Kuralları
- Alttaki parçalardan birine tıklayarak seç
- Tahta üzerinde istediğin yere tıkla, parça yerleşir
- Tam dolan **satır** veya **sütun** temizlenir
- Üst üste temizlersen **COMBO** bonusu kazanırsın
- Hiçbir parçanın sığmadığı yer kalmadığında oyun biter

### Kontroller
- **Parça seç**: Alttaki 3 parçadan birine tıkla
- **Yerleştir**: Tahtada istediğin hücreye tıkla (önizleme görünür)
- **Döndür**: "↻ DÖNDÜR" butonuna bas

### Puan Sistemi
- Her yerleştirilen hücre: **10 puan**
- Satır/Sütun temizleme: **100 × Seviye × Temizlenen sayısı**
- Combo (2+): **50 × Seviye × Combo sayısı**
- Seviye her 5 temizlemede 1 artar

### Dosya Yapısı
```
app/src/main/
├── java/com/example/blockgame/
│   ├── MainActivity.kt       — UI controller
│   ├── GameEngine.kt         — Oyun mantığı
│   ├── GameBoardView.kt      — Özel tahta çizimi
│   ├── PieceView.kt          — Parça görüntüleme
│   └── GameModels.kt         — Veri modelleri
└── res/
    ├── layout/activity_main.xml
    ├── values/colors.xml, themes.xml
    └── font/                 — Google Downloadable Fonts
```
