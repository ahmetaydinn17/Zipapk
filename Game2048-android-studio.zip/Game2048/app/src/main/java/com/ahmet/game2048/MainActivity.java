package com.ahmet.game2048;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity {

    private static final int SIZE = 4;
    private static final String PREFS = "game_2048_prefs";
    private static final String KEY_BEST = "best_score";

    private final int[][] board = new int[SIZE][SIZE];
    private int[][] previousBoard;
    private int score = 0;
    private int previousScore = 0;
    private int bestScore = 0;
    private boolean hasWon = false;

    private GridLayout boardGrid;
    private TextView[][] cellViews;
    private TextView scoreText;
    private TextView bestText;
    private Button undoButton;

    private SharedPreferences preferences;
    private final Random random = new Random();
    private GestureDetector gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        bestScore = preferences.getInt(KEY_BEST, 0);

        boardGrid = findViewById(R.id.boardGrid);
        scoreText = findViewById(R.id.scoreText);
        bestText = findViewById(R.id.bestText);
        Button newGameButton = findViewById(R.id.newGameButton);
        undoButton = findViewById(R.id.undoButton);
        View gestureContainer = findViewById(R.id.gestureContainer);

        gestureDetector = new GestureDetector(this, new SwipeListener());
        gestureContainer.setOnTouchListener((v, event) -> gestureDetector.onTouchEvent(event));

        createBoardViews();
        newGameButton.setOnClickListener(v -> startNewGame());
        undoButton.setOnClickListener(v -> undoMove());

        updateBest();
        startNewGame();
    }

    private void createBoardViews() {
        cellViews = new TextView[SIZE][SIZE];
        boardGrid.post(() -> {
            boardGrid.removeAllViews();
            int totalWidth = boardGrid.getWidth() - dp(20);
            int cellSize = totalWidth / SIZE - dp(6);
            if (cellSize <= 0) {
                cellSize = dp(72);
            }

            for (int row = 0; row < SIZE; row++) {
                for (int col = 0; col < SIZE; col++) {
                    TextView cell = new TextView(this);
                    GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                    params.width = cellSize;
                    params.height = cellSize;
                    params.setMargins(dp(4), dp(4), dp(4), dp(4));
                    cell.setLayoutParams(params);
                    cell.setGravity(Gravity.CENTER);
                    cell.setTypeface(Typeface.DEFAULT_BOLD);
                    cell.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
                    cell.setBackgroundColor(getColorCompat(R.color.empty_cell));
                    cell.setTextColor(getColorCompat(R.color.text_dark));
                    boardGrid.addView(cell);
                    cellViews[row][col] = cell;
                }
            }
            renderBoard();
        });
    }

    private void startNewGame() {
        clearBoard();
        score = 0;
        previousScore = 0;
        previousBoard = null;
        hasWon = false;
        addRandomTile();
        addRandomTile();
        renderBoard();
        updateUndoButton();
    }

    private void clearBoard() {
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                board[row][col] = 0;
            }
        }
    }

    private void undoMove() {
        if (previousBoard == null) {
            return;
        }
        for (int row = 0; row < SIZE; row++) {
            System.arraycopy(previousBoard[row], 0, board[row], 0, SIZE);
        }
        score = previousScore;
        renderBoard();
        previousBoard = null;
        updateUndoButton();
    }

    private void saveStateForUndo() {
        previousBoard = new int[SIZE][SIZE];
        for (int row = 0; row < SIZE; row++) {
            System.arraycopy(board[row], 0, previousBoard[row], 0, SIZE);
        }
        previousScore = score;
        updateUndoButton();
    }

    private void handleMove(Direction direction) {
        saveStateForUndo();
        boolean moved;
        switch (direction) {
            case LEFT:
                moved = moveLeft();
                break;
            case RIGHT:
                reverseRows();
                moved = moveLeft();
                reverseRows();
                break;
            case UP:
                transpose();
                moved = moveLeft();
                transpose();
                break;
            case DOWN:
                transpose();
                reverseRows();
                moved = moveLeft();
                reverseRows();
                transpose();
                break;
            default:
                moved = false;
        }

        if (!moved) {
            previousBoard = null;
            updateUndoButton();
            return;
        }

        addRandomTile();
        renderBoard();

        if (!hasWon && containsValue(2048)) {
            hasWon = true;
            showMessage("Tebrikler!", "2048 yaptın. Devam edip daha yüksek skor kasabilirsin.");
        } else if (isGameOver()) {
            showGameOverDialog();
        }
    }

    private boolean moveLeft() {
        boolean moved = false;
        for (int row = 0; row < SIZE; row++) {
            int[] original = board[row].clone();
            int[] compressed = compressRow(board[row]);
            int[] merged = mergeRow(compressed);
            int[] finalRow = compressRow(merged);
            board[row] = finalRow;
            if (!rowsEqual(original, finalRow)) {
                moved = true;
            }
        }
        return moved;
    }

    private int[] compressRow(int[] row) {
        int[] newRow = new int[SIZE];
        int index = 0;
        for (int value : row) {
            if (value != 0) {
                newRow[index++] = value;
            }
        }
        return newRow;
    }

    private int[] mergeRow(int[] row) {
        int[] newRow = row.clone();
        for (int i = 0; i < SIZE - 1; i++) {
            if (newRow[i] != 0 && newRow[i] == newRow[i + 1]) {
                newRow[i] *= 2;
                score += newRow[i];
                newRow[i + 1] = 0;
            }
        }
        return newRow;
    }

    private void reverseRows() {
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE / 2; col++) {
                int temp = board[row][col];
                board[row][col] = board[row][SIZE - 1 - col];
                board[row][SIZE - 1 - col] = temp;
            }
        }
    }

    private void transpose() {
        for (int row = 0; row < SIZE; row++) {
            for (int col = row + 1; col < SIZE; col++) {
                int temp = board[row][col];
                board[row][col] = board[col][row];
                board[col][row] = temp;
            }
        }
    }

    private boolean rowsEqual(int[] first, int[] second) {
        for (int i = 0; i < SIZE; i++) {
            if (first[i] != second[i]) {
                return false;
            }
        }
        return true;
    }

    private void addRandomTile() {
        List<int[]> emptyCells = new ArrayList<>();
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                if (board[row][col] == 0) {
                    emptyCells.add(new int[]{row, col});
                }
            }
        }

        if (emptyCells.isEmpty()) {
            return;
        }

        Collections.shuffle(emptyCells, random);
        int[] cell = emptyCells.get(0);
        board[cell[0]][cell[1]] = random.nextFloat() < 0.9f ? 2 : 4;
    }

    private boolean containsValue(int target) {
        for (int[] row : board) {
            for (int value : row) {
                if (value == target) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isGameOver() {
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                if (board[row][col] == 0) {
                    return false;
                }
                if (col < SIZE - 1 && board[row][col] == board[row][col + 1]) {
                    return false;
                }
                if (row < SIZE - 1 && board[row][col] == board[row + 1][col]) {
                    return false;
                }
            }
        }
        return true;
    }

    private void showGameOverDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Oyun Bitti")
                .setMessage("Skorun: " + score + "\nTekrar denemek ister misin?")
                .setPositiveButton("Yeni Oyun", (dialog, which) -> startNewGame())
                .setNegativeButton("Kapat", null)
                .show();
    }

    private void showMessage(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Tamam", null)
                .show();
    }

    private void renderBoard() {
        if (cellViews == null || cellViews[0][0] == null) {
            return;
        }

        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                TextView cell = cellViews[row][col];
                int value = board[row][col];
                if (value == 0) {
                    cell.setText("");
                } else {
                    cell.setText(String.valueOf(value));
                }
                cell.setBackgroundColor(getTileColor(value));
                cell.setTextColor(value <= 4 ? getColorCompat(R.color.text_dark) : getColorCompat(R.color.text_light));
                cell.setTextSize(TypedValue.COMPLEX_UNIT_SP, value >= 1024 ? 18 : value >= 128 ? 20 : 24);
            }
        }

        scoreText.setText(String.valueOf(score));
        if (score > bestScore) {
            bestScore = score;
            preferences.edit().putInt(KEY_BEST, bestScore).apply();
        }
        updateBest();
    }

    private void updateBest() {
        bestText.setText(String.valueOf(bestScore));
    }

    private void updateUndoButton() {
        undoButton.setEnabled(previousBoard != null);
        undoButton.setAlpha(previousBoard != null ? 1f : 0.5f);
    }

    private int getTileColor(int value) {
        switch (value) {
            case 0:
                return getColorCompat(R.color.empty_cell);
            case 2:
                return getColorCompat(R.color.tile_2);
            case 4:
                return getColorCompat(R.color.tile_4);
            case 8:
                return getColorCompat(R.color.tile_8);
            case 16:
                return getColorCompat(R.color.tile_16);
            case 32:
                return getColorCompat(R.color.tile_32);
            case 64:
                return getColorCompat(R.color.tile_64);
            case 128:
                return getColorCompat(R.color.tile_128);
            case 256:
                return getColorCompat(R.color.tile_256);
            case 512:
                return getColorCompat(R.color.tile_512);
            case 1024:
                return getColorCompat(R.color.tile_1024);
            case 2048:
                return getColorCompat(R.color.tile_2048);
            default:
                return getColorCompat(R.color.tile_big);
        }
    }

    private int getColorCompat(int colorRes) {
        return getResources().getColor(colorRes, getTheme());
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value,
                getResources().getDisplayMetrics()
        );
    }

    private enum Direction {
        LEFT, RIGHT, UP, DOWN
    }

    private class SwipeListener extends GestureDetector.SimpleOnGestureListener {
        private static final int SWIPE_DISTANCE_THRESHOLD = 100;
        private static final int SWIPE_VELOCITY_THRESHOLD = 100;

        @Override
        public boolean onDown(MotionEvent e) {
            return true;
        }

        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            if (e1 == null || e2 == null) {
                return false;
            }

            float diffX = e2.getX() - e1.getX();
            float diffY = e2.getY() - e1.getY();
            if (Math.abs(diffX) > Math.abs(diffY)) {
                if (Math.abs(diffX) > SWIPE_DISTANCE_THRESHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                    handleMove(diffX > 0 ? Direction.RIGHT : Direction.LEFT);
                    return true;
                }
            } else {
                if (Math.abs(diffY) > SWIPE_DISTANCE_THRESHOLD && Math.abs(velocityY) > SWIPE_VELOCITY_THRESHOLD) {
                    handleMove(diffY > 0 ? Direction.DOWN : Direction.UP);
                    return true;
                }
            }
            return false;
        }
    }
}
