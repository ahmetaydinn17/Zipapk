2048 Android Studio Projesi

Teknoloji seçimi:
- Android Gradle Plugin: 9.1.0
- Gradle dağıtımı: 9.3.1 (gradle-wrapper.properties içinde ayarlı)
- compileSdk / targetSdk: 36
- Java: 17
- androidx.core:core:1.17.0
- androidx.activity:activity:1.12.4
- androidTest: junit 1.3.0, espresso 3.7.0

Özellikler:
- 4x4 klasik 2048 oynanışı
- Kaydırma ile hareket
- Skor / en iyi skor
- Yeni oyun
- Tek hamle geri al
- 2048 ve oyun bitti uyarıları

Not:
Bu zip içinde gradle-wrapper.jar dosyasını internet erişimi olmadığı için ekleyemedim.
Ama gradle-wrapper.properties dosyası Gradle 9.3.1'e ayarlı durumda.
Android Studio'da açınca gerekirse wrapper dosyalarını yeniden oluşturabilirsin.
