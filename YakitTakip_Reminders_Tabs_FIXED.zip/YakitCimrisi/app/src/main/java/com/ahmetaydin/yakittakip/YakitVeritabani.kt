package com.ahmetaydin.yakittakip

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context

@Database(entities = [YakitKaydi::class], version = 1, exportSchema = false)
abstract class YakitVeritabani : RoomDatabase() {
    abstract fun yakitDao(): YakitDao

    companion object {
        @Volatile
        private var Instance: YakitVeritabani? = null

        fun veritabaniGetir(context: Context): YakitVeritabani {
            return Instance ?: synchronized(this) {
                Room.databaseBuilder(context, YakitVeritabani::class.java, "yakit_db")
                    .build().also { Instance = it }
            }
        }
    }
}