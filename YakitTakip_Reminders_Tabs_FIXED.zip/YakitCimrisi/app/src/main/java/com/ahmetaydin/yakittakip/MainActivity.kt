@file:kotlin.OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class
)

package com.ahmetaydin.yakittakip

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.ads.MobileAds
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.delay

// --- ANALİZ MODELİ (1 KM HESABI DAHİL) ---
data class YakitAnalizi(
    val tip: String,
    val toplamKm: Double,
    val toplamLt: Double,
    val toplamTl: Double
) {
    val birKmTl = if (toplamKm > 0) toplamTl / toplamKm else 0.0
    val birKmLt = if (toplamKm > 0) toplamLt / toplamKm else 0.0
    val yuzKmLt = if (toplamKm > 0) (toplamLt / toplamKm) * 100 else 0.0
}

enum class KmInputMode { ODOMETRE, MESAFE }

// --- YAPAY ZEKA MOTORU ---
@kotlin.OptIn(ExperimentalGetImage::class)
fun analyzeReceipt(imageProxy: ImageProxy, onResult: (String, String) -> Unit) {
    val mediaImage = imageProxy.image
    if (mediaImage == null) {
        imageProxy.close()
        return
    }

    fun parseTrDouble(raw: String): Double? {
        // Turkish format: 1.850,53  or 36,550  or 2.890
        val s = raw.trim()
            .replace("₺", "")
            .replace("TL", "", ignoreCase = true)
            .replace(" ", "")
            .replace(".", "")     // remove thousand separators
            .replace(",", ".")    // decimal comma -> dot
        return s.toDoubleOrNull()
    }

    val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    recognizer.process(image)
        .addOnSuccessListener { visionText ->
            var detectedLitre = ""
            var detectedTotal = ""

            val lines = visionText.text.split("\n")

            // 1) Prefer "LT x UnitPrice" lines and ALWAYS compute total if possible (Mode B)
            // Examples:
            // 50,630 LT X 36,550
            // 52,780 LT x 2,890
            // 84,15 LT × 51,22
            val ltXPriceRegex = Regex("""(\d{1,3}(?:[.,]\d{1,3})+|\d+[.,]\d+|\d+)\s*(?:LT|LİT(?:RE)?|LIT(?:RE)?)\s*[*xX×]\s*(\d{1,3}(?:[.,]\d{1,3})+|\d+[.,]\d+|\d+)""")

            // Also sometimes product line has: "KURŞUNSUZ 95 %20 *1.850,53"
            // We'll still compute from LT x price when possible, but keep this as a fallback.
            val numberRegex = Regex("""\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})|\d+[.,]\d+|\d+""")

            var litreVal: Double? = null
            var unitPriceVal: Double? = null

            // First pass: try to find LT x price in one line
            for (line in lines) {
                val upper = line.uppercase()
                val m = ltXPriceRegex.find(upper)
                if (m != null) {
                    val lRaw = m.groupValues[1]
                    val pRaw = m.groupValues[2]
                    litreVal = parseTrDouble(lRaw)
                    unitPriceVal = parseTrDouble(pRaw)
                    if (litreVal != null && unitPriceVal != null) break
                }
            }

            // Second pass: if not found in one line, try to detect litre and unit price separately
            if (litreVal == null || unitPriceVal == null) {
                for (line in lines) {
                    val upper = line.uppercase()

                    // litre candidates
                    if (litreVal == null && (upper.contains("LT") || upper.contains("LİTRE") || upper.contains("LITRE") || upper.contains("MİKTAR"))) {
                        val nums = numberRegex.findAll(line).map { it.value }.toList()
                        // usually the first numeric token on litre line
                        nums.firstOrNull()?.let { litreVal = parseTrDouble(it) }
                    }

                    // unit price candidates
                    if (unitPriceVal == null && (upper.contains("BİRİM") || upper.contains("FIYAT") || upper.contains("FİYAT") || upper.contains("TL/LT") || upper.contains("TL/")) ) {
                        val nums = numberRegex.findAll(line).map { it.value }.toList()
                        // usually the last numeric token is price
                        nums.lastOrNull()?.let { unitPriceVal = parseTrDouble(it) }
                    }

                    if (litreVal != null && unitPriceVal != null) break
                }
            }

            // Fill detected litre string (for UI field)
            litreVal?.let { detectedLitre = "%.2f".format(it).replace(",", ".") }

            // Compute total if we have both
            if (litreVal != null && unitPriceVal != null) {
                val total = litreVal!! * unitPriceVal!!
                detectedTotal = "%.2f".format(total).replace(",", ".")
            } else {
                // Fallback: try to get TOPLAM/TUTAR style lines
                for (line in lines) {
                    val upper = line.uppercase()
                    if (upper.contains("TOPLAM") || upper.contains("TUTAR") || upper.contains("ÖDENECEK") || upper.contains("ODEME") || upper.contains("PAY")) {
                        val nums = numberRegex.findAll(line).map { it.value }.toList()
                        // usually the last number on total line is the amount
                        nums.lastOrNull()?.let { detectedTotal = it }
                    }
                    if (detectedTotal.isNotEmpty()) break
                }
            }

            onResult(detectedLitre, detectedTotal)
        }
        .addOnCompleteListener { imageProxy.close() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // AdMob init + preload (live IDs are in Ads.kt)
        MobileAds.initialize(this) {}
        Ads.preloadInterstitial(this)
        Ads.preloadRewarded(this)

        setContent {
            MaterialTheme {
                val db = YakitVeritabani.veritabaniGetir(applicationContext)
                val factory = object : ViewModelProvider.Factory {
                    override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                        @Suppress("UNCHECKED_CAST")
                        return YakitViewModel(db.yakitDao()) as T
                    }
                }
                GarajliYakitEkrani(viewModel(factory = factory))
            }
        }
    }
}

@Composable
fun GarajliYakitEkrani(viewModel: YakitViewModel) {
    val kayitlar by viewModel.tumKayitlar.collectAsState(initial = emptyList())

    val context = LocalContext.current
    val activity = context as? Activity
    val coin by CoinStore.coinFlow(context).collectAsState(initial = 0)
    val scope = rememberCoroutineScope()

    val vehicleState by (secilenPlaka?.let { VehicleStore.vehicleFlow(context, it) } ?: flowOf(VehicleStore.VehicleState())).collectAsState(initial = VehicleStore.VehicleState())

    val ARAC_EKLE_MALIYET = 20
    val PDF_MALIYET = 20
    val REWARDED_ODUL = 10

    var secilenPlaka by remember { mutableStateOf<String?>(null) }
    var yeniAracModu by remember { mutableStateOf(false) }
    var yeniPlakaInput by remember { mutableStateOf("") }
    var fisEklemeModu by remember { mutableStateOf(false) }
    var showCamera by remember { mutableStateOf(false) }

    var km by remember { mutableStateOf("") }
    var litre by remember { mutableStateOf("") }
    var tl by remember { mutableStateOf("") }
    var secilenYakitTipi by remember { mutableStateOf("Benzin") }

    var coinDialog by remember { mutableStateOf(false) }
    var pdfDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.arka_plan),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        Scaffold(containerColor = Color.Transparent) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(16.dp)
                    .fillMaxSize()
            ) {

                // --- TOP BAR: PDF + COIN ---
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { pdfDialog = true },
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .background(Color.White.copy(alpha = 0.9f), CircleShape)
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF", tint = Color(0xFF003399))
                    }

                    Surface(
                        color = Color.White.copy(alpha = 0.9f),
                        shape = RoundedCornerShape(999.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = Color(0xFF2E7D32))
                            Spacer(Modifier.width(6.dp))
                            Text("$coin coin", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // --- CONTENT (banner altta görünmesi için weight) ---
                Box(modifier = Modifier.weight(1f)) {
                    when {
                        yeniAracModu -> {
                            AracEklemeGörünümü(
                                inputPlaka = yeniPlakaInput,
                                onPlaka = { yeniPlakaInput = it },
                                inputBaslangicKm = yeniBaslangicKmInput,
                                onBaslangicKm = { yeniBaslangicKmInput = it },
                                onIptal = { yeniAracModu = false; yeniPlakaInput = ""; yeniBaslangicKmInput = "" },
                                onKaydet = {
                                    val pl = yeniPlakaInput.trim()
                                    val basKm = yeniBaslangicKmInput.toIntOrNull()
                                    if (pl.isNotEmpty() && basKm != null && basKm >= 0) {
                                        secilenPlaka = pl
                                        scope.launch { VehicleStore.initVehicle(context, pl, basKm) }
                                        yeniAracModu = false
                                    }
                                }
                            )
                        }

                        secilenPlaka != null -> {
                            val aracKayitlari = kayitlar.filter { it.plaka == secilenPlaka }
                            AnalizSayfasi(
                                plaka = secilenPlaka!!,
                                kayitlar = aracKayitlari,
                                onGeri = { secilenPlaka = null },
                                onYeniFis = { fisEklemeModu = true },
                                onSil = { viewModel.fisSil(it) }
                            )
                        }

                        else -> {
                            AnaAracListesi(
                                kayitlar = kayitlar,
                                onSec = { secilenPlaka = it },
                                onSil = { viewModel.aracSil(it) },
                                onEkle = {
                                    if (coin >= ARAC_EKLE_MALIYET) {
                                        scope.launch {
                                            val ok = CoinStore.spendCoin(context, ARAC_EKLE_MALIYET)
                                            if (ok) yeniAracModu = true else coinDialog = true
                                        }
                                    } else {
                                        coinDialog = true
                                    }
                                }
                            )
                        }
                    }
                }

                // --- ANA EKRAN BANNER (her zaman en altta) ---
                if (secilenPlaka == null && !yeniAracModu) {
                    BannerAd(modifier = Modifier.fillMaxWidth().height(50.dp))
                }
            }
        }

        // --- FİŞ EKLEME ---
        if (fisEklemeModu) {
            ModalBottomSheet(onDismissRequest = { fisEklemeModu = false }) {
                Column(
                    modifier = Modifier.padding(16.dp).padding(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("FİŞ BİLGİLERİ", fontWeight = FontWeight.Bold)

                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        listOf("Benzin", "LPG", "Dizel").forEach { tip ->
                            FilterChip(
                                selected = secilenYakitTipi == tip,
                                onClick = { secilenYakitTipi = tip },
                                label = { Text(tip) }
                            )
                            Spacer(Modifier.width(8.dp))
                        }
                    }

                    Button(
                        onClick = { showCamera = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00BCD4))
                    ) {
                        Icon(Icons.Default.PhotoCamera, null)
                        Spacer(Modifier.width(8.dp))
                        Text("YAPAY ZEKA İLE TARA")
                    }
Row(Modifier.horizontalScroll(rememberScrollState())) {
    FilterChip(
        selected = kmMode == KmInputMode.ODOMETRE,
        onClick = { kmMode = KmInputMode.ODOMETRE },
        label = { Text("Araç KM") }
    )
    Spacer(Modifier.width(8.dp))
    FilterChip(
        selected = kmMode == KmInputMode.MESAFE,
        onClick = { kmMode = KmInputMode.MESAFE },
        label = { Text("Gidilen KM") }
    )
}
Text(
    text = if (kmMode == KmInputMode.ODOMETRE) "Mevcut kayıtlı KM: ${vehicleState.currentKm}" else "Mevcut kayıtlı KM: ${vehicleState.currentKm} (Üzerine eklenecek)",
    fontSize = 12.sp,
    color = Color.Gray
)

Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InputKutusu(km, { km = it }, if (kmMode == KmInputMode.ODOMETRE) "Araç KM" else "Gidilen KM", Modifier.weight(1f))
                        InputKutusu(litre, { litre = it }, "Litre", Modifier.weight(1f))
                        InputKutusu(tl, { tl = it }, "Tutar ₺", Modifier.weight(1f))
                    }

                    Button(
                        onClick = {
val enteredKm = km.toIntOrNull() ?: 0
val t = tl.toDoubleOrNull() ?: 0.0
val l = litre.toDoubleOrNull() ?: 0.0

val plaka = secilenPlaka ?: return@Button
val current = vehicleState.currentKm

// KM hesapla: 2 mod
val (tripKm, newCurrentKm) = if (kmMode == KmInputMode.ODOMETRE) {
    val odo = enteredKm
    val trip = (odo - current).coerceAtLeast(0)
    trip.toDouble() to odo
} else {
    val trip = enteredKm.coerceAtLeast(0)
    trip.toDouble() to (current + trip)
}

if (tripKm > 0 && t > 0) {
    viewModel.kayitEkle(plaka, secilenYakitTipi, l, t, tripKm)
    scope.launch {
        VehicleStore.setCurrentKm(context, plaka, newCurrentKm)
        // Yağ hatırlatma kontrolü (yakıt eklenince)
        checkOilReminder(
            context = context,
            plaka = plaka,
            currentKm = newCurrentKm
        )
        // Tarih bazlıları da kontrol et (uygulama açıkken)
        checkDateReminders(context, plaka)
    }

    km = ""; litre = ""; tl = ""; fisEklemeModu = false

    // --- HER YAKIT EKLEME SONRASI GEÇİŞ REKLAMI ---
    if (activity != null) Ads.showInterstitial(activity)
}
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003399))
                    ) {
                        Text("KAYDI TAMAMLA")
                    }
                }
            }
        }

        // --- CAMERA ---
        if (showCamera) {
            CameraDialog(
                onDismiss = { showCamera = false },
                onCaptured = { l, t ->
                    if (l.isNotEmpty()) litre = l.replace(",", ".")
                    if (t.isNotEmpty()) tl = t.replace(",", ".")
                }
            )
        }

        // --- PDF DİYALOĞU ---
        if (pdfDialog) {
            AlertDialog(
                onDismissRequest = { pdfDialog = false },
                title = { Text("PDF (Tüm Veriler)") },
                text = { Text("Tüm kayıtları PDF olarak almak için $PDF_MALIYET coin gerekir.") },
                confirmButton = {
                    Button(onClick = {
                        scope.launch {
                            val ok = CoinStore.spendCoin(context, PDF_MALIYET)
                            if (ok) {
                                val intent = PdfExporter.exportAllRecordsPdf(
                                    context = context,
                                    title = "Yakıt Takip - Tüm Kayıtlar",
                                    records = kayitlar
                                )
                                context.startActivity(Intent.createChooser(intent, "PDF Paylaş / Kaydet"))
                            } else {
                                coinDialog = true
                            }
                        }
                        pdfDialog = false
                    }) { Text("PDF AL ($PDF_MALIYET coin)") }
                },
                dismissButton = {
                    TextButton(onClick = { pdfDialog = false }) { Text("Vazgeç") }
                }
            )
        }

        // --- COIN YETERSİZ: REWARDED ---
        if (coinDialog) {
            AlertDialog(
                onDismissRequest = { coinDialog = false },
                title = { Text("Coin gerekli") },
                text = { Text("Yeterli coin yok. Reklam izleyerek +$REWARDED_ODUL coin kazanabilirsin.") },
                confirmButton = {
                    Button(onClick = {
                        if (activity != null) {
                            Ads.showRewarded(activity) {
                                scope.launch { CoinStore.addCoin(context, REWARDED_ODUL) }
                            }
                        }
                        coinDialog = false
                    }) {
                        Text("REKLAM İZLE (+$REWARDED_ODUL)")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { coinDialog = false }) { Text("Vazgeç") }
                }
            )
        }
    }
}

@Composable
fun CameraDialog(onDismiss: () -> Unit, onCaptured: (String, String) -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val context = LocalContext.current

        var hasPermission by remember {
            mutableStateOf(
                ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            )
        }

        // Tek seferlik yakalama + 5 sn timeout
        var captured by remember { mutableStateOf(false) }
        var bestLitre by remember { mutableStateOf("") }
        var bestTotal by remember { mutableStateOf("") }

        // 5 saniye içinde hiç okuma yoksa uyar (otomatik kapatma YOK)
        var timedOut by remember { mutableStateOf(false) }
        var sessionKey by remember { mutableStateOf(0) }

        LaunchedEffect(hasPermission, sessionKey) {
            if (hasPermission) {
                captured = false
                timedOut = false
                bestLitre = ""
                bestTotal = ""
                delay(5000)
                if (!captured) {
                    timedOut = true
                    Toast.makeText(context, "Okunamadı (ışık/açı düzeltip tekrar dene)", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val permissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) { granted ->
            hasPermission = granted
        }

        val lifecycleOwner = LocalLifecycleOwner.current

        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            if (!hasPermission) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Kamera izni gerekli", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) {
                        Text("İZİN VER")
                    }
                }
            } else {
                AndroidView(
                    factory = { ctx ->
                        val previewView = PreviewView(ctx)
                        val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                        cameraProviderFuture.addListener({
                            val cameraProvider = cameraProviderFuture.get()
                            val preview = Preview.Builder().build().apply {
                                setSurfaceProvider(previewView.surfaceProvider)
                            }
                            val analysis = ImageAnalysis.Builder()
                                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                .build()

                            analysis.setAnalyzer(ContextCompat.getMainExecutor(ctx)) { proxy ->
                                if (captured) {
                                    proxy.close()
                                    return@setAnalyzer
                                }
                                analyzeReceipt(proxy) { l, t ->
                                    if (captured) return@analyzeReceipt

                                    if (bestLitre.isEmpty() && l.isNotEmpty()) bestLitre = l
                                    if (bestTotal.isEmpty() && t.isNotEmpty()) bestTotal = t

                                    // İKİSİ de bulunduysa -> Tarandı, kapat
                                    if (bestLitre.isNotEmpty() && bestTotal.isNotEmpty() && !captured) {
                                        captured = true
                                        timedOut = false
                                        Toast.makeText(context, "Tarandı", Toast.LENGTH_SHORT).show()
                                        onCaptured(bestLitre, bestTotal)
                                    }
                                }
                            }

                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                CameraSelector.DEFAULT_BACK_CAMERA,
                                preview,
                                analysis
                            )
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            
            // Okunamadı veya Tarandı durumunda kullanıcıya "Tekrar Dene" butonu göster
            if (hasPermission && (captured || timedOut)) {
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                        .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (captured) "Sonuç alındı. İstersen tekrar deneyebilirsin."
                        else "Okunamadı. Işık/açı düzeltip tekrar dene.",
                        color = Color.White,
                        fontSize = 12.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(10.dp))
                    Button(
                        onClick = {
                            sessionKey += 1
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00BCD4))
                    ) { Text("TEKRAR DENE") }
                }
            }

IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp)
                    .background(Color.Black.copy(0.5f), CircleShape)
            ) {
                Icon(Icons.Default.Close, null, tint = Color.White)
            }
        }
    }
}

@Composable
fun AnalizSayfasi(
    plaka: String,
    kayitlar: List<YakitKaydi>,
    onGeri: () -> Unit,
    onYeniFis: () -> Unit,
    onSil: (Int) -> Unit
) {
    var tabIndex by remember { mutableStateOf(0) }
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onGeri) { Icon(Icons.Default.ArrowBack, null) }
            Spacer(Modifier.width(8.dp))
            PlakaTabelasi(plaka, Modifier.width(160.dp))
        }

        androidx.compose.material3.TabRow(selectedTabIndex = tabIndex) {
            androidx.compose.material3.Tab(
                selected = tabIndex == 0,
                onClick = { tabIndex = 0 },
                text = { Text("Yakıt") }
            )
            androidx.compose.material3.Tab(
                selected = tabIndex == 1,
                onClick = { tabIndex = 1 },
                text = { Text("Hatırlatmalar") }
            )
        }


if (tabIndex == 0) {
    val yakitTipleri = listOf("Benzin", "LPG", "Dizel")
        val genel = YakitAnalizi(
            "GENEL TOPLAM",
            kayitlar.sumOf { it.gidilenKm },
            kayitlar.sumOf { it.miktar },
            kayitlar.sumOf { it.tutar }
        )
        GelismişAnalizKarti(genel, Color(0xFF003399))

        Row(modifier = Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
            yakitTipleri.forEach { tip ->
                val filtreli = kayitlar.filter { it.yakitTipi == tip }
                if (filtreli.isNotEmpty()) {
                    val analiz = YakitAnalizi(
                        tip,
                        filtreli.sumOf { it.gidilenKm },
                        filtreli.sumOf { it.miktar },
                        filtreli.sumOf { it.tutar }
                    )
                    Box(modifier = Modifier.width(260.dp).padding(end = 8.dp)) {
                        GelismişAnalizKarti(
                            analiz,
                            if (tip == "Benzin") Color(0xFFD32F2F) else Color(0xFF388E3C)
                        )
                    }
                }
            }
        }

        Button(
            onClick = onYeniFis,
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003399))
        ) {
            Text("YENİ FİŞ GİRİŞİ")
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(kayitlar.reversed()) { kayit ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(0.9f))
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "${kayit.yakitTipi} | ${kayit.gidilenKm} KM",
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { onSil(kayit.id) }) {
                                Icon(Icons.Default.Delete, null, tint = Color.Gray)
                            }
                        }
                        Text("Tutar: ${kayit.tutar} ₺ | Litre: ${kayit.miktar} L", fontSize = 13.sp)

                        val verim = if (kayit.gidilenKm > 0) (kayit.miktar / kayit.gidilenKm) * 100 else 0.0
                        val birKmTl = if (kayit.gidilenKm > 0) (kayit.tutar / kayit.gidilenKm) else 0.0

                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Ortalama: ${"%.2f".format(verim)} L/100KM",
                                color = Color(0xFF003399),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                "1 KM: ${"%.2f".format(birKmTl)} ₺",
                                color = Color(0xFF2E7D32),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
        } else {
            HatirlatmalarSayfasi(plaka = plaka)
        }
    }
}

@Composable
fun HatirlatmalarSayfasi(plaka: String) {
    val context = LocalContext.current
    val st by VehicleStore.vehicleFlow(context, plaka).collectAsState(initial = VehicleStore.VehicleState())

    var lastOil by remember { mutableStateOf(if (st.oilLastKm == 0) "" else st.oilLastKm.toString()) }
    var interval by remember { mutableStateOf(st.oilIntervalKm.toString()) }

    var muayene by remember { mutableStateOf(if (st.muayeneMillis == 0L) "" else millisToDate(st.muayeneMillis)) }
    var sigorta by remember { mutableStateOf(if (st.sigortaMillis == 0L) "" else millisToDate(st.sigortaMillis)) }
    var kasko by remember { mutableStateOf(if (st.kaskoMillis == 0L) "" else millisToDate(st.kaskoMillis)) }

    // state update when datastore changes
    androidx.compose.runtime.LaunchedEffect(st.oilLastKm, st.oilIntervalKm) {
        if (lastOil.isBlank()) lastOil = if (st.oilLastKm == 0) "" else st.oilLastKm.toString()
        interval = st.oilIntervalKm.toString()
    }
    androidx.compose.runtime.LaunchedEffect(st.muayeneMillis) { muayene = if (st.muayeneMillis == 0L) "" else millisToDate(st.muayeneMillis) }
    androidx.compose.runtime.LaunchedEffect(st.sigortaMillis) { sigorta = if (st.sigortaMillis == 0L) "" else millisToDate(st.sigortaMillis) }
    androidx.compose.runtime.LaunchedEffect(st.kaskoMillis) { kasko = if (st.kaskoMillis == 0L) "" else millisToDate(st.kaskoMillis) }

    val nextOil = if (st.oilLastKm > 0) st.oilLastKm + st.oilIntervalKm else 0
    val remainingOil = if (nextOil > 0) nextOil - st.currentKm else 0

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize().padding(top = 12.dp)
    ) {

        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(0.92f))) {
                Column(Modifier.padding(12.dp)) {
                    Text("Yağ + Periyodik Bakım", fontWeight = FontWeight.Bold, color = Color(0xFF003399))
                    Spacer(Modifier.height(8.dp))
                    Text("Araç KM: ${st.currentKm}", color = Color.Gray, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = lastOil,
                        onValueChange = { lastOil = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Son yağ değişimi (KM)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = interval,
                        onValueChange = { interval = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Değişim aralığı (KM) (Varsayılan 10000)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(8.dp))
                    if (nextOil > 0) {
                        Text("Hedef: $nextOil km • Kalan: ${remainingOil.coerceAtLeast(0)} km", fontWeight = FontWeight.SemiBold)
                    } else {
                        Text("Yağ bilgilerini girince hedef KM hesaplanır.", color = Color.Gray, fontSize = 12.sp)
                    }

                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = {
                                val l = lastOil.toIntOrNull() ?: 0
                                val i = interval.toIntOrNull() ?: 10000
                                scope.launch {
                                    VehicleStore.setOilSettings(context, plaka, l, i)
                                    checkOilReminder(context, plaka, st.currentKm)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003399))
                        ) { Text("Kaydet") }

                        Button(
                            onClick = {
                                scope.launch {
                                    VehicleStore.markOilChangedNow(context, plaka, st.currentKm)
                                    checkOilReminder(context, plaka, st.currentKm)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                        ) { Text("Yağ değiştirildi") }
                    }

                    Spacer(Modifier.height(6.dp))
                    Text("Bildirimler: 500 km kala, 200 km kala ve zamanı gelince.", color = Color.Gray, fontSize = 11.sp)
                }
            }
        }

        item { TarihKarti(title = "Muayene", value = muayene, onValue = { muayene = it }, onSave = {
            val millis = dateToMillis(muayene)
            scope.launch {
                VehicleStore.setDate(context, plaka, "muayene", millis)
                checkDateReminders(context, plaka)
            }
        }) }

        item { TarihKarti(title = "Sigorta", value = sigorta, onValue = { sigorta = it }, onSave = {
            val millis = dateToMillis(sigorta)
            scope.launch {
                VehicleStore.setDate(context, plaka, "sigorta", millis)
                checkDateReminders(context, plaka)
            }
        }) }

        item { TarihKarti(title = "Kasko", value = kasko, onValue = { kasko = it }, onSave = {
            val millis = dateToMillis(kasko)
            scope.launch {
                VehicleStore.setDate(context, plaka, "kasko", millis)
                checkDateReminders(context, plaka)
            }
        }) }

        item {
            Text("Tarih formatı: YYYY-MM-DD (Örn: 2026-03-15)", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 4.dp))
        }
    }
}

@Composable
private fun TarihKarti(
    title: String,
    value: String,
    onValue: (String) -> Unit,
    onSave: () -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(0.92f))) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Color(0xFF003399))
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = value,
                onValueChange = { onValue(it) },
                label = { Text("$title bitiş tarihi (YYYY-MM-DD)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = onSave,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003399))
            ) { Text("Kaydet") }

            Spacer(Modifier.height(6.dp))
            Text("Bildirimler: 1 hafta kala, 1 gün kala ve süresi dolunca.", color = Color.Gray, fontSize = 11.sp)
        }
    }
}

private fun dateToMillis(s: String): Long {
    return try {
        val d = LocalDate.parse(s.trim(), DateTimeFormatter.ISO_LOCAL_DATE)
        d.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    } catch (_: Exception) {
        0L
    }
}

private fun millisToDate(millis: Long): String {
    return try {
        val d = java.time.Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate()
        d.format(DateTimeFormatter.ISO_LOCAL_DATE)
    } catch (_: Exception) { "" }
}

@Composable
fun AnaAracListesi(
    kayitlar: List<YakitKaydi>,
    onSec: (String) -> Unit,
    onSil: (String) -> Unit,
    onEkle: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = Color(0xFF003399), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
            Text(
                "GARAJIM",
                color = Color.White,
                modifier = Modifier.padding(12.dp),
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(16.dp))
        val plakalar = kayitlar.map { it.plaka }.distinct()

        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(plakalar) { plaka ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PlakaTabelasi(plaka, Modifier.weight(1f).clickable { onSec(plaka) })
                    IconButton(onClick = { onSil(plaka) }) { Icon(Icons.Default.Delete, null, tint = Color.Red) }
                }
            }
        }

        Button(
            onClick = onEkle,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003399))
        ) {
            Text("ARAÇ EKLE")
        }
    }
}

@Composable
fun AracEklemeGörünümü(
    inputPlaka: String,
    onPlaka: (String) -> Unit,
    inputBaslangicKm: String,
    onBaslangicKm: (String) -> Unit,
    onIptal: () -> Unit,
    onKaydet: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        PlakaTabelasi(if (inputPlaka.isEmpty()) "PLAKA" else inputPlaka)
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = inputPlaka,
            onValueChange = { if (it.length <= 9) onPlaka(it.uppercase()) },
            label = { Text("Plaka Girin (Maks 9 Karakter)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = inputBaslangicKm,
            onValueChange = { onBaslangicKm(it.filter { ch -> ch.isDigit() }) },
            label = { Text("Başlangıç KM (Zorunlu)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )

        Row(Modifier.padding(top = 16.dp)) {
            Button(
                onClick = onIptal,
                Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
            ) { Text("İPTAL") }

            Spacer(Modifier.width(8.dp))

            Button(
                onClick = onKaydet,
                Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003399))
            ) { Text("KAYDET") }
        }
    }
}

@Composable
fun InputKutusu(v: String, onV: (String) -> Unit, l: String, m: Modifier) {
    OutlinedTextField(
        value = v,
        onValueChange = onV,
        label = { Text(l) },
        modifier = m,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
    )
}

@Composable
fun PlakaTabelasi(p: String, m: Modifier = Modifier) {
    Card(
        modifier = m.height(50.dp).border(2.dp, Color.Black, RoundedCornerShape(6.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.fillMaxHeight().width(30.dp).background(Color(0xFF003399)),
                contentAlignment = Alignment.BottomCenter
            ) {
                Text(
                    "TR",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }
            Text(
                text = p,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                color = Color.Black,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}

@Composable
fun GelismişAnalizKarti(a: YakitAnalizi, r: Color) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(0.95f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(a.tip, fontWeight = FontWeight.Black, color = r, fontSize = 13.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("1 KM / ₺", fontSize = 10.sp, color = Color.Gray)
                    Text("%.2f ₺".format(a.birKmTl), fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                }
                Column {
                    Text("100 KM / L", fontSize = 10.sp, color = Color.Gray)
                    Text("%.2f L".format(a.yuzKmLt), fontWeight = FontWeight.Bold)
                }
                Column {
                    Text("TOPLAM", fontSize = 10.sp, color = Color.Gray)
                    Text("%.0f ₺".format(a.toplamTl), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// --- HATIRLATMA KONTROLLERİ ---
// Not: Bildirimler uygulama açıkken kesin çalışır. İstersen daha sonra WorkManager ile arka plana da taşırız.

suspend fun checkOilReminder(context: android.content.Context, plaka: String, currentKm: Int) {
    val st = VehicleStore.vehicleFlow(context, plaka).first()
    if (!st.hasInit) return

    val interval = st.oilIntervalKm.coerceAtLeast(1000)
    val last = st.oilLastKm
    if (last <= 0) return // kullanıcı ayarlamadı

    val next = last + interval
    val remaining = next - currentKm

    // 500 km
    if (remaining <= 500 && remaining > 200 && !st.oilNot500) {
        Notifier.notify(context, (plaka.hashCode() * 31) + 500, "Yağ / Bakım", "$plaka • Yağ değişimine 500 km kaldı (hedef: $next km)")
        VehicleStore.setOilNotified(context, plaka, 500)
    }
    // 200 km
    if (remaining <= 200 && remaining > 0 && !st.oilNot200) {
        Notifier.notify(context, (plaka.hashCode() * 31) + 200, "Yağ / Bakım", "$plaka • Yağ değişimine 200 km kaldı (hedef: $next km)")
        VehicleStore.setOilNotified(context, plaka, 200)
    }
    // geldi / geçti
    if (remaining <= 0 && !st.oilNot0) {
        Notifier.notify(context, (plaka.hashCode() * 31), "Yağ / Bakım", "$plaka • Yağ değişimi zamanı geldi! (hedef: $next km)")
        VehicleStore.setOilNotified(context, plaka, 0)
    }
}

suspend fun checkDateReminders(context: android.content.Context, plaka: String) {
    val st = VehicleStore.vehicleFlow(context, plaka).first()
    fun daysUntil(millis: Long): Long {
        if (millis <= 0L) return Long.MAX_VALUE
        val now = System.currentTimeMillis()
        return ((millis - now) / (1000L * 60 * 60 * 24))
    }

    fun check(type: String, label: String, dateMillis: Long, not7: Boolean, not1: Boolean, notExp: Boolean) {
        if (dateMillis <= 0L) return
        val d = daysUntil(dateMillis)
        val idBase = (plaka.hashCode() * 97) + type.hashCode()

        if (d <= 7 && d > 1 && !not7) {
            Notifier.notify(context, idBase + 7, label, "$plaka • $label için 1 hafta kaldı")
            // fire and forget
        }
        if (d <= 1 && d >= 0 && !not1) {
            Notifier.notify(context, idBase + 1, label, "$plaka • $label yarın/bugün bitiyor")
        }
        if (d < 0 && !notExp) {
            Notifier.notify(context, idBase, label, "$plaka • $label süresi bitti")
        }
    }

    // Muayene
    check("muayene","Muayene", st.muayeneMillis, st.muayeneNot7, st.muayeneNot1, st.muayeneNotExp)
    // Sigorta
    check("sigorta","Sigorta", st.sigortaMillis, st.sigortaNot7, st.sigortaNot1, st.sigortaNotExp)
    // Kasko
    check("kasko","Kasko", st.kaskoMillis, st.kaskoNot7, st.kaskoNot1, st.kaskoNotExp)

    // Bayrak güncellemeleri (daha sade: sadece koşul sağlandıysa işaretle)
    val now = System.currentTimeMillis()
    fun upd(type: String, dateMillis: Long) {
        if (dateMillis <= 0L) return
        val d = ((dateMillis - now) / (1000L * 60 * 60 * 24))
        if (d <= 7 && d > 1) {
            VehicleStore.setDateNotified(context, plaka, type, "7")
        }
        if (d <= 1 && d >= 0) {
            VehicleStore.setDateNotified(context, plaka, type, "1")
        }
        if (d < 0) {
            VehicleStore.setDateNotified(context, plaka, type, "exp")
        }
    }
    upd("muayene", st.muayeneMillis)
    upd("sigorta", st.sigortaMillis)
    upd("kasko", st.kaskoMillis)
}
