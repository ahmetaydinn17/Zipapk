package com.ahmetaydin.yakittakip

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.Flow

class YakitViewModel(private val dao: YakitDao) : ViewModel() {
    val tumKayitlar: Flow<List<YakitKaydi>> = dao.tumunuGetir()

    fun kayitEkle(plaka: String, yakitTipi: String, miktar: Double, tutar: Double, km: Double) {
        viewModelScope.launch {
            dao.ekle(YakitKaydi(
                plaka = plaka,
                yakitTipi = yakitTipi,
                miktar = miktar,
                tutar = tutar,
                gidilenKm = km,
                tarih = System.currentTimeMillis()
            ))
        }
    }

    // Araç silme fonksiyonu
    fun aracSil(plaka: String) {
        viewModelScope.launch {
            dao.plakayaGoreSil(plaka)
        }
    }

    // Tekil fiş silme fonksiyonu
    fun fisSil(id: Int) {
        viewModelScope.launch {
            dao.idyeGoreSil(id)
        }
    }
}