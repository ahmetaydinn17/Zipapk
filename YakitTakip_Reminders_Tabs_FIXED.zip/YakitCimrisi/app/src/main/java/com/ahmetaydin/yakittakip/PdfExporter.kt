package com.ahmetaydin.yakittakip

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import kotlin.comparisons.thenBy

object PdfExporter {

    /**
     * Creates a PDF containing all records and returns an ACTION_SEND intent for sharing/saving.
     * Requires FileProvider configured with authority: ${applicationId}.fileprovider
     */
    fun exportAllRecordsPdf(
        context: Context,
        title: String,
        records: List<YakitKaydi>
    ): Intent {
        val doc = PdfDocument()

        val pageWidth = 595  // A4 @ 72dpi
        val pageHeight = 842

        val margin = 32
        val lineH = 18

        val paintTitle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val paintSub = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val paintBold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        // Yakıt ekleme tarihi için format
        val dateFmtRow = java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale("tr", "TR"))

        var pageNumber = 1
        var y = margin

        fun newPage(): Pair<PdfDocument.Page, Canvas> {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            val page = doc.startPage(pageInfo)
            val canvas = page.canvas
            y = margin

            // Header
            canvas.drawText(title, margin.toFloat(), y.toFloat(), paintTitle)
            y += (lineH + 6)

            val now = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale("tr", "TR"))
                .format(java.util.Date())
            canvas.drawText("Oluşturma: $now", margin.toFloat(), y.toFloat(), paintSub)
            y += (lineH + 10)

            // Column header
            canvas.drawText("Plaka", margin.toFloat(), y.toFloat(), paintBold)
            canvas.drawText("Tip", (margin + 90).toFloat(), y.toFloat(), paintBold)
            canvas.drawText("Tarih", (margin + 160).toFloat(), y.toFloat(), paintBold)
            canvas.drawText("KM", (margin + 260).toFloat(), y.toFloat(), paintBold)
            canvas.drawText("Litre", (margin + 330).toFloat(), y.toFloat(), paintBold)
            canvas.drawText("Tutar (₺)", (margin + 410).toFloat(), y.toFloat(), paintBold)
            y += (lineH + 6)

            return page to canvas
        }

        var (page, canvas) = newPage()

        // Totals
        var totalKm = 0.0
        var totalLt = 0.0
        var totalTl = 0.0

        // Keep a stable ordering: by plate, then insertion order.
        val rows = records.sortedWith(compareBy<YakitKaydi> { it.plaka }.thenBy { it.id })

        for (r in rows) {
            // New page if needed
            if (y > pageHeight - margin - 60) {
                doc.finishPage(page)
                pageNumber += 1
                val np = newPage()
                page = np.first
                canvas = np.second
            }

            canvas.drawText(r.plaka, margin.toFloat(), y.toFloat(), paintSub)
            canvas.drawText(r.yakitTipi, (margin + 90).toFloat(), y.toFloat(), paintSub)
            canvas.drawText(dateFmtRow.format(java.util.Date(r.tarih)), (margin + 160).toFloat(), y.toFloat(), paintSub)
            canvas.drawText("%.0f".format(r.gidilenKm), (margin + 260).toFloat(), y.toFloat(), paintSub)
            canvas.drawText("%.2f".format(r.miktar), (margin + 330).toFloat(), y.toFloat(), paintSub)
            canvas.drawText("%.2f".format(r.tutar), (margin + 410).toFloat(), y.toFloat(), paintSub)

            y += lineH

            totalKm += r.gidilenKm
            totalLt += r.miktar
            totalTl += r.tutar
        }

        // Footer totals
        if (y > pageHeight - margin - 60) {
            doc.finishPage(page)
            pageNumber += 1
            val np = newPage()
            page = np.first
            canvas = np.second
        }

        y += 10
        canvas.drawText("TOPLAM", margin.toFloat(), y.toFloat(), paintBold)
        canvas.drawText("%.0f KM".format(totalKm), (margin + 260).toFloat(), y.toFloat(), paintBold)
        canvas.drawText("%.2f L".format(totalLt), (margin + 330).toFloat(), y.toFloat(), paintBold)
        canvas.drawText("%.2f ₺".format(totalTl), (margin + 410).toFloat(), y.toFloat(), paintBold)

        doc.finishPage(page)

        // Save file
        val outDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val safeName = "yakit_takip_${System.currentTimeMillis()}.pdf"
        val outFile = File(outDir, safeName)
        FileOutputStream(outFile).use { doc.writeTo(it) }
        doc.close()

        val uri = FileProvider.getUriForFile(
            context,
            context.packageName + ".fileprovider",
            outFile
        )

        return Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
