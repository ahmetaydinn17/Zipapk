package com.ahmetaydin.yakittakip

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.vehicleStore by preferencesDataStore(name = "vehicle_store")

/**
 * Araç bazlı (plaka bazlı) KM ve hatırlatma ayarları DataStore'da tutulur.
 * Room migration ile uğraşmamak için en pratik ve stabil yol.
 */
object VehicleStore {

    // --- helpers ---
    private fun keyCurrentKm(plaka: String) = intPreferencesKey("${plaka}_current_km")
    private fun keyHasInit(plaka: String) = booleanPreferencesKey("${plaka}_has_init")

    // Oil
    private fun keyOilLastKm(plaka: String) = intPreferencesKey("${plaka}_oil_last_km")
    private fun keyOilInterval(plaka: String) = intPreferencesKey("${plaka}_oil_interval_km")
    private fun keyOilNot500(plaka: String) = booleanPreferencesKey("${plaka}_oil_not_500")
    private fun keyOilNot200(plaka: String) = booleanPreferencesKey("${plaka}_oil_not_200")
    private fun keyOilNot0(plaka: String) = booleanPreferencesKey("${plaka}_oil_not_0")

    // Dates (millis)
    private fun keyMuayene(plaka: String) = longPreferencesKey("${plaka}_muayene_date")
    private fun keySigorta(plaka: String) = longPreferencesKey("${plaka}_sigorta_date")
    private fun keyKasko(plaka: String) = longPreferencesKey("${plaka}_kasko_date")

    private fun keyDateNot7(plaka: String, type: String) = booleanPreferencesKey("${plaka}_${type}_not_7")
    private fun keyDateNot1(plaka: String, type: String) = booleanPreferencesKey("${plaka}_${type}_not_1")
    private fun keyDateNotExp(plaka: String, type: String) = booleanPreferencesKey("${plaka}_${type}_not_exp")

    data class VehicleState(
        val hasInit: Boolean = false,
        val currentKm: Int = 0,
        val oilLastKm: Int = 0,
        val oilIntervalKm: Int = 10000,
        val muayeneMillis: Long = 0L,
        val sigortaMillis: Long = 0L,
        val kaskoMillis: Long = 0L,
        val oilNot500: Boolean = false,
        val oilNot200: Boolean = false,
        val oilNot0: Boolean = false,
        val muayeneNot7: Boolean = false,
        val muayeneNot1: Boolean = false,
        val muayeneNotExp: Boolean = false,
        val sigortaNot7: Boolean = false,
        val sigortaNot1: Boolean = false,
        val sigortaNotExp: Boolean = false,
        val kaskoNot7: Boolean = false,
        val kaskoNot1: Boolean = false,
        val kaskoNotExp: Boolean = false,
    )

    fun vehicleFlow(context: Context, plaka: String): Flow<VehicleState> =
        context.vehicleStore.data.map { p ->
            VehicleState(
                hasInit = p[keyHasInit(plaka)] ?: false,
                currentKm = p[keyCurrentKm(plaka)] ?: 0,
                oilLastKm = p[keyOilLastKm(plaka)] ?: 0,
                oilIntervalKm = p[keyOilInterval(plaka)] ?: 10000,
                muayeneMillis = p[keyMuayene(plaka)] ?: 0L,
                sigortaMillis = p[keySigorta(plaka)] ?: 0L,
                kaskoMillis = p[keyKasko(plaka)] ?: 0L,
                oilNot500 = p[keyOilNot500(plaka)] ?: false,
                oilNot200 = p[keyOilNot200(plaka)] ?: false,
                oilNot0 = p[keyOilNot0(plaka)] ?: false,
                muayeneNot7 = p[keyDateNot7(plaka,"muayene")] ?: false,
                muayeneNot1 = p[keyDateNot1(plaka,"muayene")] ?: false,
                muayeneNotExp = p[keyDateNotExp(plaka,"muayene")] ?: false,
                sigortaNot7 = p[keyDateNot7(plaka,"sigorta")] ?: false,
                sigortaNot1 = p[keyDateNot1(plaka,"sigorta")] ?: false,
                sigortaNotExp = p[keyDateNotExp(plaka,"sigorta")] ?: false,
                kaskoNot7 = p[keyDateNot7(plaka,"kasko")] ?: false,
                kaskoNot1 = p[keyDateNot1(plaka,"kasko")] ?: false,
                kaskoNotExp = p[keyDateNotExp(plaka,"kasko")] ?: false,
            )
        }

    suspend fun initVehicle(context: Context, plaka: String, startingKm: Int) {
        context.vehicleStore.edit { p ->
            p[keyHasInit(plaka)] = true
            p[keyCurrentKm(plaka)] = startingKm.coerceAtLeast(0)
        }
    }

    suspend fun setCurrentKm(context: Context, plaka: String, newKm: Int) {
        context.vehicleStore.edit { p -> p[keyCurrentKm(plaka)] = newKm.coerceAtLeast(0) }
    }

    suspend fun setOilSettings(context: Context, plaka: String, lastKm: Int, intervalKm: Int) {
        context.vehicleStore.edit { p ->
            p[keyOilLastKm(plaka)] = lastKm.coerceAtLeast(0)
            p[keyOilInterval(plaka)] = intervalKm.coerceAtLeast(1000)
            // reset notifications (yeniden ayarladıysa)
            p[keyOilNot500(plaka)] = false
            p[keyOilNot200(plaka)] = false
            p[keyOilNot0(plaka)] = false
        }
    }

    suspend fun markOilChangedNow(context: Context, plaka: String, currentKm: Int) {
        context.vehicleStore.edit { p ->
            p[keyOilLastKm(plaka)] = currentKm.coerceAtLeast(0)
            p[keyOilNot500(plaka)] = false
            p[keyOilNot200(plaka)] = false
            p[keyOilNot0(plaka)] = false
        }
    }

    suspend fun setOilNotified(context: Context, plaka: String, level: Int) {
        context.vehicleStore.edit { p ->
            when(level){
                500 -> p[keyOilNot500(plaka)] = true
                200 -> p[keyOilNot200(plaka)] = true
                0 -> p[keyOilNot0(plaka)] = true
            }
        }
    }

    suspend fun setDate(context: Context, plaka: String, type: String, millis: Long) {
        context.vehicleStore.edit { p ->
            when(type){
                "muayene" -> p[keyMuayene(plaka)] = millis
                "sigorta" -> p[keySigorta(plaka)] = millis
                "kasko" -> p[keyKasko(plaka)] = millis
            }
            // reset notifs for that type
            p[keyDateNot7(plaka,type)] = false
            p[keyDateNot1(plaka,type)] = false
            p[keyDateNotExp(plaka,type)] = false
        }
    }

    suspend fun setDateNotified(context: Context, plaka: String, type: String, which: String) {
        context.vehicleStore.edit { p ->
            when(which){
                "7" -> p[keyDateNot7(plaka,type)] = true
                "1" -> p[keyDateNot1(plaka,type)] = true
                "exp" -> p[keyDateNotExp(plaka,type)] = true
            }
        }
    }
}