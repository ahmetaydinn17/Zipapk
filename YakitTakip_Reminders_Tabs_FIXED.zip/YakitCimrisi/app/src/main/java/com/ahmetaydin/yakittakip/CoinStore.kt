package com.ahmetaydin.yakittakip

import android.content.Context
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "coin_store")

object CoinStore {
    private val KEY_COIN = intPreferencesKey("coin")

    fun coinFlow(context: Context): Flow<Int> =
        context.dataStore.data.map { prefs -> prefs[KEY_COIN] ?: 0 }

    suspend fun addCoin(context: Context, amount: Int) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_COIN] ?: 0
            prefs[KEY_COIN] = (current + amount).coerceAtLeast(0)
        }
    }

    /** Returns true if coin spent, false if insufficient. */
    suspend fun spendCoin(context: Context, amount: Int): Boolean {
        var ok = false
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_COIN] ?: 0
            if (current >= amount) {
                prefs[KEY_COIN] = current - amount
                ok = true
            }
        }
        return ok
    }
}
