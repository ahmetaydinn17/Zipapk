package com.ahmetaydin.yakittakip

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface YakitDao {
    @Query("SELECT * FROM yakit_tablosu")
    fun tumunuGetir(): Flow<List<YakitKaydi>>

    @Insert
    suspend fun ekle(kayit: YakitKaydi)

    // Seçilen plakaya ait her şeyi siler
    @Query("DELETE FROM yakit_tablosu WHERE plaka = :plaka")
    suspend fun plakayaGoreSil(plaka: String)

    // Sadece seçilen fişi siler
    @Query("DELETE FROM yakit_tablosu WHERE id = :id")
    suspend fun idyeGoreSil(id: Int)
}