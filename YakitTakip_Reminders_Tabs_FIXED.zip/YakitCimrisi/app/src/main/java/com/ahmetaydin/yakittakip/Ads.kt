package com.ahmetaydin.yakittakip

import android.app.Activity
import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

object Ads {
    // LIVE Ad Unit IDs (from your AdMob panel)
    const val BANNER_ID = "ca-app-pub-5873234983926555/9265440173"
    const val INTERSTITIAL_ID = "ca-app-pub-5873234983926555/5822541693"
    const val REWARDED_ID = "ca-app-pub-5873234983926555/1766912464"

    private var interstitial: InterstitialAd? = null
    private var rewarded: RewardedAd? = null

    // --- Interstitial kuralı: 3 yakıt eklemede 1 + 60sn cooldown ---
    private var fuelAddCounter = 0
    private var lastInterstitialShowMs = 0L
    private const val INTERSTITIAL_EVERY_N = 3
    private const val INTERSTITIAL_COOLDOWN_MS = 60_000L

    fun preloadInterstitial(context: Context) {
        if (interstitial != null) return

        InterstitialAd.load(
            context,
            INTERSTITIAL_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitial = ad
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            interstitial = null
                            preloadInterstitial(context)
                        }

                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            interstitial = null
                            preloadInterstitial(context)
                        }
                    }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitial = null
                }
            }
        )
    }

    /** Direkt göster (istersen kullan). */
    fun showInterstitial(activity: Activity) {
        val ad = interstitial
        if (ad != null) {
            lastInterstitialShowMs = System.currentTimeMillis()
            ad.show(activity)
        } else {
            preloadInterstitial(activity)
        }
    }

    /**
     * Yakıt kaydı eklendikten sonra çağır:
     * - her 3 eklemede 1 interstitial
     * - ayrıca 60sn cooldown var
     */
    fun onFuelAddedAndMaybeShow(activity: Activity) {
        fuelAddCounter++

        val now = System.currentTimeMillis()
        val cooldownOk = (now - lastInterstitialShowMs) >= INTERSTITIAL_COOLDOWN_MS
        val stepOk = (fuelAddCounter % INTERSTITIAL_EVERY_N == 0)

        if (stepOk && cooldownOk) {
            val ad = interstitial
            if (ad != null) {
                lastInterstitialShowMs = now
                ad.show(activity)
            } else {
                preloadInterstitial(activity)
            }
        } else {
            if (interstitial == null) preloadInterstitial(activity)
        }
    }

    fun preloadRewarded(context: Context) {
        if (rewarded != null) return

        RewardedAd.load(
            context,
            REWARDED_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewarded = ad
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            rewarded = null
                            preloadRewarded(context)
                        }

                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            rewarded = null
                            preloadRewarded(context)
                        }
                    }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewarded = null
                }
            }
        )
    }

    fun showRewarded(activity: Activity, onReward: (RewardItem) -> Unit) {
        val ad = rewarded
        if (ad != null) {
            ad.show(activity) { reward -> onReward(reward) }
        } else {
            preloadRewarded(activity)
        }
    }
}

@Composable
fun BannerAd(modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            AdView(ctx).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = Ads.BANNER_ID
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}