package com.ahmetaydin.yakittakip

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "yakit_tablosu")
data class YakitKaydi(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val plaka: String,
    val yakitTipi: String,
    val miktar: Double,
    val tutar: Double,
    val gidilenKm: Double,
    val tarih: Long = System.currentTimeMillis() // Veri girildiği anın zamanı
)