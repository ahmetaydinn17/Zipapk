plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    id("org.jetbrains.kotlin.kapt")
}

android {
    namespace = "com.ahmetaydin.yakittakip"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ahmetaydin.yakittakip"
        minSdk = 26
        targetSdk = 35 // compileSdk ile aynı olması en sağlıklısıdır
        versionCode = 2
        versionName = "1.1"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // APK isimlendirme kısmını daha modern bir yöntemle düzelttik
    androidComponents {
        onVariants { variant ->
            variant.outputs.forEach { output ->
                if (output is com.android.build.api.variant.impl.VariantOutputImpl) {
                    output.outputFileName.set("YakitTakip_v${variant.outputs.size}.apk")
                }
            }
        }
    }

    buildFeatures { compose = true }
    // Kotlin 1.9.0 ile uyumlu en stabil sürüm
compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    // Eski hali: kotlinOptions { jvmTarget = "17" }
// Yeni hali (Bunu yapıştır):
    kotlin {
        compilerOptions {
            jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        }
    }
}

dependencies {
    // Temel Kütüphaneler (libs.versions.toml'dan gelenler)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation("com.google.guava:guava:33.2.1-android")
    implementation("androidx.compose.material:material-icons-extended:1.7.0")

    // --- KAMERA VE YAPAY ZEKA (Sürümler Sabitlendi) ---
    val camerax_version = "1.3.4" // En stabil ve uyumlu sürüm
    implementation("androidx.camera:camera-core:${camerax_version}")
    implementation("androidx.camera:camera-camera2:${camerax_version}")
    implementation("androidx.camera:camera-lifecycle:${camerax_version}")
    implementation("androidx.camera:camera-view:${camerax_version}")

    // ML Kit Metin Tanıma (Tek sürüm)
    implementation("com.google.mlkit:text-recognition:16.0.0")

    // --- REKLAM (AdMob) ---
    implementation("com.google.android.gms:play-services-ads:25.0.0")

    // --- VERİTABANI (Room) ---
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    kapt(libs.androidx.room.compiler)

    // DataStore (Coin)
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // Test Kütüphaneleri
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}