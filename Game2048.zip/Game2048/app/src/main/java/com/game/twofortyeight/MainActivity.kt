package com.game.twofortyeight

import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.game.twofortyeight.databinding.ActivityMainBinding
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: GameViewModel by viewModels()
    private lateinit var gestureDetector: GestureDetector

    companion object {
        private const val SWIPE_THRESHOLD = 80f
        private const val SWIPE_VELOCITY_THRESHOLD = 100f
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupGestureDetector()
        observeGameState()
        setupButtons()
    }

    private fun setupGestureDetector() {
        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                val dx = e2.x - (e1?.x ?: 0f)
                val dy = e2.y - (e1?.y ?: 0f)

                if (abs(dx) > abs(dy)) {
                    if (abs(dx) > SWIPE_THRESHOLD && abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                        if (dx > 0) viewModel.move(Direction.RIGHT)
                        else viewModel.move(Direction.LEFT)
                        return true
                    }
                } else {
                    if (abs(dy) > SWIPE_THRESHOLD && abs(velocityY) > SWIPE_VELOCITY_THRESHOLD) {
                        if (dy > 0) viewModel.move(Direction.DOWN)
                        else viewModel.move(Direction.UP)
                        return true
                    }
                }
                return false
            }
        })

        binding.gameBoardView.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            true
        }
    }

    private fun observeGameState() {
        viewModel.gameState.observe(this) { state ->
            binding.gameBoardView.updateBoard(state.board)
            binding.tvScore.text = state.score.toString()
            binding.tvBest.text = state.bestScore.toString()

            if (state.hasWon && !shownWinDialog) {
                shownWinDialog = true
                showDialog("🎉 Kazandın!", "2048'e ulaştın! Oynamaya devam etmek ister misin?", continueOption = true)
            } else if (state.isGameOver) {
                showDialog("Oyun Bitti", "Skor: ${state.score}\nYeni oyun oynamak ister misin?", continueOption = false)
            }
        }
    }

    private var shownWinDialog = false

    private fun setupButtons() {
        binding.btnNewGame.setOnClickListener {
            shownWinDialog = false
            viewModel.newGame()
        }
    }

    private fun showDialog(title: String, message: String, continueOption: Boolean) {
        val builder = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setCancelable(false)
            .setPositiveButton("Yeni Oyun") { _, _ ->
                shownWinDialog = false
                viewModel.newGame()
            }

        if (continueOption) {
            builder.setNegativeButton("Devam Et") { dialog, _ -> dialog.dismiss() }
        }

        builder.show()
    }
}
