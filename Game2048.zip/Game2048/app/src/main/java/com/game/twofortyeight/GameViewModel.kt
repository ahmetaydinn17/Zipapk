package com.game.twofortyeight

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class GameViewModel : ViewModel() {

    private val engine = GameEngine()

    private val _gameState = MutableLiveData<GameState>()
    val gameState: LiveData<GameState> = _gameState

    init {
        newGame()
    }

    fun newGame() {
        _gameState.value = engine.newGame()
    }

    fun move(direction: Direction) {
        val currentState = _gameState.value ?: return
        if (currentState.isGameOver) return
        _gameState.value = engine.move(direction)
    }
}
