package com.game.twofortyeight

import kotlin.random.Random

enum class Direction { UP, DOWN, LEFT, RIGHT }

data class GameState(
    val board: Array<IntArray> = Array(4) { IntArray(4) },
    val score: Int = 0,
    val bestScore: Int = 0,
    val isGameOver: Boolean = false,
    val hasWon: Boolean = false
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is GameState) return false
        if (!board.contentDeepEquals(other.board)) return false
        if (score != other.score) return false
        if (bestScore != other.bestScore) return false
        if (isGameOver != other.isGameOver) return false
        if (hasWon != other.hasWon) return false
        return true
    }

    override fun hashCode(): Int {
        var result = board.contentDeepHashCode()
        result = 31 * result + score
        result = 31 * result + bestScore
        result = 31 * result + isGameOver.hashCode()
        result = 31 * result + hasWon.hashCode()
        return result
    }
}

class GameEngine {

    private var board = Array(4) { IntArray(4) }
    private var score = 0
    private var bestScore = 0
    private var hasWon = false

    fun newGame(): GameState {
        board = Array(4) { IntArray(4) }
        score = 0
        hasWon = false
        addRandomTile()
        addRandomTile()
        return getState()
    }

    fun move(direction: Direction): GameState {
        val previousBoard = board.map { it.copyOf() }.toTypedArray()
        var moved = false
        var pointsGained = 0

        when (direction) {
            Direction.LEFT -> {
                for (row in 0..3) {
                    val result = mergeRow(board[row])
                    if (!board[row].contentEquals(result.first)) moved = true
                    board[row] = result.first
                    pointsGained += result.second
                }
            }
            Direction.RIGHT -> {
                for (row in 0..3) {
                    val reversed = board[row].reversed().toIntArray()
                    val result = mergeRow(reversed)
                    val newRow = result.first.reversed().toIntArray()
                    if (!board[row].contentEquals(newRow)) moved = true
                    board[row] = newRow
                    pointsGained += result.second
                }
            }
            Direction.UP -> {
                for (col in 0..3) {
                    val column = IntArray(4) { board[it][col] }
                    val result = mergeRow(column)
                    if (!column.contentEquals(result.first)) moved = true
                    for (row in 0..3) board[row][col] = result.first[row]
                    pointsGained += result.second
                }
            }
            Direction.DOWN -> {
                for (col in 0..3) {
                    val column = IntArray(4) { board[it][col] }.reversed().toIntArray()
                    val result = mergeRow(column)
                    val newCol = result.first.reversed().toIntArray()
                    val original = IntArray(4) { board[it][col] }
                    if (!original.contentEquals(newCol)) moved = true
                    for (row in 0..3) board[row][col] = newCol[row]
                    pointsGained += result.second
                }
            }
        }

        if (moved) {
            score += pointsGained
            if (score > bestScore) bestScore = score
            addRandomTile()
            if (!hasWon && hasTile(2048)) hasWon = true
        }

        return getState()
    }

    private fun mergeRow(row: IntArray): Pair<IntArray, Int> {
        val tiles = row.filter { it != 0 }.toMutableList()
        val result = IntArray(4)
        var points = 0
        var i = 0
        var j = 0

        while (i < tiles.size) {
            if (i + 1 < tiles.size && tiles[i] == tiles[i + 1]) {
                val merged = tiles[i] * 2
                result[j++] = merged
                points += merged
                i += 2
            } else {
                result[j++] = tiles[i++]
            }
        }

        return Pair(result, points)
    }

    private fun addRandomTile() {
        val emptyCells = mutableListOf<Pair<Int, Int>>()
        for (r in 0..3) for (c in 0..3) if (board[r][c] == 0) emptyCells.add(r to c)
        if (emptyCells.isEmpty()) return
        val (r, c) = emptyCells[Random.nextInt(emptyCells.size)]
        board[r][c] = if (Random.nextFloat() < 0.9f) 2 else 4
    }

    private fun hasTile(value: Int): Boolean =
        board.any { row -> row.any { it == value } }

    private fun isGameOver(): Boolean {
        for (r in 0..3) for (c in 0..3) {
            if (board[r][c] == 0) return false
            if (r < 3 && board[r][c] == board[r + 1][c]) return false
            if (c < 3 && board[r][c] == board[r][c + 1]) return false
        }
        return true
    }

    private fun getState(): GameState {
        val boardCopy = board.map { it.copyOf() }.toTypedArray()
        return GameState(
            board = boardCopy,
            score = score,
            bestScore = bestScore,
            isGameOver = isGameOver(),
            hasWon = hasWon
        )
    }
}
