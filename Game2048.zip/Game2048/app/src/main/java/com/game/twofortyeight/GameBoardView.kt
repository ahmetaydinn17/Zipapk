package com.game.twofortyeight

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator

class GameBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        color = Color.WHITE
    }

    private var board: Array<IntArray> = Array(4) { IntArray(4) }
    private val gap = 12f
    private val cornerRadius = 8f

    private val tileColors = mapOf(
        0 to Color.parseColor("#CDC1B4"),
        2 to Color.parseColor("#EEE4DA"),
        4 to Color.parseColor("#EDE0C8"),
        8 to Color.parseColor("#F2B179"),
        16 to Color.parseColor("#F59563"),
        32 to Color.parseColor("#F67C5F"),
        64 to Color.parseColor("#F65E3B"),
        128 to Color.parseColor("#EDCF72"),
        256 to Color.parseColor("#EDCC61"),
        512 to Color.parseColor("#EDC850"),
        1024 to Color.parseColor("#EDC53F"),
        2048 to Color.parseColor("#EDC22E")
    )

    private val textColors = mapOf(
        2 to Color.parseColor("#776E65"),
        4 to Color.parseColor("#776E65")
    )

    fun updateBoard(newBoard: Array<IntArray>) {
        board = newBoard
        invalidate()
        startAppearAnimation()
    }

    private fun startAppearAnimation() {
        val animator = ObjectAnimator.ofFloat(this, "alpha", 0.85f, 1f)
        animator.duration = 150
        animator.interpolator = AccelerateDecelerateInterpolator()
        animator.start()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(width, width)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val totalGap = gap * 5
        val tileSize = (width - totalGap) / 4f

        paint.color = Color.parseColor("#BBADA0")
        canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), cornerRadius * 2, cornerRadius * 2, paint)

        for (row in 0..3) {
            for (col in 0..3) {
                val value = board[row][col]
                val left = gap + col * (tileSize + gap)
                val top = gap + row * (tileSize + gap)
                val right = left + tileSize
                val bottom = top + tileSize
                val rect = RectF(left, top, right, bottom)

                paint.color = tileColors[value] ?: Color.parseColor("#3D3A33")
                canvas.drawRoundRect(rect, cornerRadius, cornerRadius, paint)

                if (value != 0) {
                    textPaint.color = textColors[value] ?: Color.WHITE
                    textPaint.textSize = when {
                        value >= 1024 -> tileSize * 0.30f
                        value >= 128 -> tileSize * 0.36f
                        else -> tileSize * 0.44f
                    }
                    val textY = top + tileSize / 2f - (textPaint.descent() + textPaint.ascent()) / 2f
                    canvas.drawText(value.toString(), left + tileSize / 2f, textY, textPaint)
                }
            }
        }
    }
}
