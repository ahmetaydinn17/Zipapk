package com.ahmetaydin.yakittakip

import kotlinx.coroutines.flow.first
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// --- HATIRLATMA KONTROLLERİ ---
// Not: Bildirimler uygulama açıkken kesin çalışır. İstersen daha sonra WorkManager ile arka plana da taşırız.

suspend fun checkOilReminder(context: android.content.Context, plaka: String, currentKm: Int) {
    val st = VehicleStore.vehicleFlow(context, plaka).first()
    if (!st.hasInit) return

    val interval = st.oilIntervalKm.coerceAtLeast(1000)
    val last = st.oilLastKm
    if (last <= 0) return // kullanıcı ayarlamadı

    val next = last + interval
    val remaining = next - currentKm

    // 500 km
    if (remaining <= 500 && remaining > 200 && !st.oilNot500) {
        Notifier.notify(
            context,
            (plaka.hashCode() * 31) + 500,
            "Yağ / Bakım",
            "$plaka • Yağ değişimine 500 km kaldı (hedef: $next km)"
        )
        VehicleStore.setOilNotified(context, plaka, 500)
    }
    // 200 km
    if (remaining <= 200 && remaining > 0 && !st.oilNot200) {
        Notifier.notify(
            context,
            (plaka.hashCode() * 31) + 200,
            "Yağ / Bakım",
            "$plaka • Yağ değişimine 200 km kaldı (hedef: $next km)"
        )
        VehicleStore.setOilNotified(context, plaka, 200)
    }
    // geldi / geçti
    if (remaining <= 0 && !st.oilNot0) {
        Notifier.notify(
            context,
            (plaka.hashCode() * 31),
            "Yağ / Bakım",
            "$plaka • Yağ değişimi zamanı geldi! (hedef: $next km)"
        )
        VehicleStore.setOilNotified(context, plaka, 0)
    }
}

suspend fun checkDateReminders(context: android.content.Context, plaka: String) {
    val st = VehicleStore.vehicleFlow(context, plaka).first()
    if (!st.hasInit) return

    fun daysLeft(millis: Long): Long {
        if (millis <= 0L) return Long.MAX_VALUE
        val now = System.currentTimeMillis()
        return ((millis - now) / (1000L * 60L * 60L * 24L))
    }

    fun handle(type: String, targetMillis: Long, not7: Boolean, not1: Boolean, notExp: Boolean) {
        if (targetMillis <= 0L) return
        val d = daysLeft(targetMillis)
        val title = when (type) {
            "muayene" -> "Muayene"
            "sigorta" -> "Sigorta"
            "kasko" -> "Kasko"
            else -> "Hatırlatma"
        }

        if (d <= 7 && d > 1 && !not7) {
            Notifier.notify(context, (plaka.hashCode() * 97) + type.hashCode() + 7, title, "$plaka • $title bitimine 1 hafta kaldı")
            CoroutineScope(Dispatchers.IO).launch {
                VehicleStore.setDateNotified(context, plaka, type, "7")
            }
        }
        if (d <= 1 && d >= 0 && !not1) {
            Notifier.notify(context, (plaka.hashCode() * 97) + type.hashCode() + 1, title, "$plaka • $title son 1 gün")
            CoroutineScope(Dispatchers.IO).launch {
                VehicleStore.setDateNotified(context, plaka, type, "1")
            }
        }
        if (d < 0 && !notExp) {
            Notifier.notify(context, (plaka.hashCode() * 97) + type.hashCode(), title, "$plaka • $title süresi doldu!")
            CoroutineScope(Dispatchers.IO).launch {
                VehicleStore.setDateNotified(context, plaka, type, "exp")
            }
        }
    }

    handle("muayene", st.muayeneMillis, st.muayeneNot7, st.muayeneNot1, st.muayeneNotExp)
    handle("sigorta", st.sigortaMillis, st.sigortaNot7, st.sigortaNot1, st.sigortaNotExp)
    handle("kasko", st.kaskoMillis, st.kaskoNot7, st.kaskoNot1, st.kaskoNotExp)
}
